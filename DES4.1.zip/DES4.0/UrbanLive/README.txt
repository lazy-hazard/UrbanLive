URBAN LIVE - Sistema de gestión administrativa para condominios

TECNOLOGÍA
- Java OpenJDK 21
- Eclipse IDE
- Java Swing
- Interfaces preparadas para editarse con WindowBuilder en las pestañas Source / Design
- JUnit 5 para pruebas del código

EJECUCIÓN
1. En Eclipse: File > Import > Existing Projects into Workspace.
2. Seleccionar la carpeta del proyecto o el ZIP.
3. Abrir src/condominio/MenuPrincipal.java.
4. Run As > Java Application.

WINDOWBUILDER - DESIGN
Las ventanas gráficas están escritas con la estructura estándar de Swing que WindowBuilder reconoce:
- Cada ventana hereda de JFrame.
- Los componentes se crean directamente dentro del constructor.
- Se usa contentPane.setLayout(null) y setBounds para posicionarlos.
- No se usan métodos auxiliares para crear botones o campos.
- Los eventos usan ActionListener y ListSelectionListener.

Para editar visualmente una ventana:
1. Abrir por ejemplo VentanaDepartamentos.java.
2. En la parte inferior del editor elegir la pestaña Design.
3. Mover, redimensionar o agregar componentes desde WindowBuilder.

MÓDULOS
- Departamentos: código, número, piso, propietario/inquilino y cuota.
- Pagos y deudas: consulta por departamento y administración protegida.
- Áreas comunes: reglas de uso, duración máxima y separación entre reservas.
- Reservas: aplica automáticamente las reglas del área.
- Mantenimiento: registro y seguimiento administrativo.

SEGURIDAD
Las herramientas administrativas solicitan la contraseña global definida en Seguridad.java.
Contraseña actual del prototipo: ADMIN123.

PRUEBAS
La carpeta test contiene pruebas JUnit 5. No forman parte de la interfaz del usuario.
