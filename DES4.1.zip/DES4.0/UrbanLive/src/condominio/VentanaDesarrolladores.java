package condominio;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;

public class VentanaDesarrolladores extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			VentanaDesarrolladores dialog = new VentanaDesarrolladores();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public VentanaDesarrolladores() {
		setModal(true);
		setResizable(false);
		setTitle("UrbanLive - Creditos");
		setBounds(100, 100, 700, 550);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			comboBox = new JComboBox<String>(new String[] {"Neomar Alfredo Guillent Yepez - N00523494", "Joaquín Mendoza Garibay - N00531650", "Adriano Tomasto Fabian - N00539492", "Alvaro Leon Astulla - N00549719", "Gianpiero Tovar Díaz - N00547739"});
			comboBox.setBounds(58, 43, 417, 22);
			contentPanel.add(comboBox);
		}
	}
}
