package condominio;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Estilos {
	public static final Color AMARILLO = new Color(220, 170, 50);
    public static final Color VERDE = new Color(25, 86, 67);
    public static final Color VERDE_OSCURO = new Color(18, 58, 47);
    public static final Color FONDO = new Color(245, 247, 246);
    public static final Color TEXTO = new Color(38, 48, 44);
    public static final Color BLANCO = Color.WHITE;
    public static final Color BLACK = Color.BLACK;
    public static final Color BLUES = new Color(116, 153, 232);

    private Estilos() { }
    public static void titulogrande(JLabel label) {
    	label.setFont(new Font("SansSerif", Font.BOLD, 32));
    	label.setForeground(BLANCO);
    }

    public static void titulo(JLabel label) {
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        label.setForeground(VERDE_OSCURO);
    }
    public static void titulomenu(JLabel label) {
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        label.setForeground(BLANCO);
    }
    public static void botonazul(JButton boton) {
        boton.setBackground(BLUES);
        boton.setForeground(BLANCO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
    }
    
    public static void subtitulo(JLabel label) {
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        label.setForeground(new Color(90, 100, 96));
    }
    public static void subtitulomenu(JLabel label) {
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        label.setForeground(BLANCO);
    }

    public static void boton(JButton boton) {
        boton.setBackground(AMARILLO);
        boton.setForeground(BLANCO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
    }

    public static JPanel panel() {
        JPanel p = new JPanel();
        p.setBackground(FONDO);
        p.setBorder(new EmptyBorder(18, 18, 18, 18));
        return p;
    }

    public static void fondo(JComponent componente) {
        componente.setBackground(FONDO);
    }
}
