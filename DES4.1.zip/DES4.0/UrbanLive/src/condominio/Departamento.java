package condominio;

public class Departamento {
    private String codigo;
    private int numero;
    private int piso;
    private String tipoOcupante;
    private double cuota;

    public Departamento(String codigo, int numero, int piso, String tipoOcupante, double cuota) {
        this.codigo = codigo;
        this.numero = numero;
        this.piso = piso;
        this.tipoOcupante = tipoOcupante;
        this.cuota = cuota;
    }

    public String getCodigo() { return codigo; }
    public int getNumero() { return numero; }
    public int getPiso() { return piso; }
    public String getTipoOcupante() { return tipoOcupante; }
    public double getCuota() { return cuota; }

    public void setNumero(int numero) { this.numero = numero; }
    public void setPiso(int piso) { this.piso = piso; }
    public void setTipoOcupante(String tipoOcupante) { this.tipoOcupante = tipoOcupante; }
    public void setCuota(double cuota) { this.cuota = cuota; }
}
