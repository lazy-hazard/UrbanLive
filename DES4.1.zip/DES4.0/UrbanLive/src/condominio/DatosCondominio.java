package condominio;

import java.util.ArrayList;
import java.util.List;

public class DatosCondominio {
    private static final DatosCondominio INSTANCIA = new DatosCondominio();

    private final ArrayList<Departamento> departamentos = new ArrayList<>();
    private final ArrayList<Pago> pagos = new ArrayList<>();
    private final ArrayList<AreaComun> areas = new ArrayList<>();
    private final ArrayList<Reserva> reservas = new ArrayList<>();
    private final ArrayList<Mantenimiento> mantenimientos = new ArrayList<>();

    private DatosCondominio() { }

    public static DatosCondominio getInstancia() {
        return INSTANCIA;
    }

    public ArrayList<Departamento> getDepartamentos() { return departamentos; }
    public ArrayList<Pago> getPagos() { return pagos; }
    public ArrayList<AreaComun> getAreas() { return areas; }
    public ArrayList<Reserva> getReservas() { return reservas; }
    public ArrayList<Mantenimiento> getMantenimientos() { return mantenimientos; }

    public Departamento buscarDepartamento(String codigo) {
        for (Departamento d : departamentos)
            if (d.getCodigo().equalsIgnoreCase(codigo)) return d;
        return null;
    }

    public Pago buscarPago(String codigo) {
        for (Pago p : pagos)
            if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        return null;
    }

    public AreaComun buscarArea(String codigo) {
        for (AreaComun a : areas)
            if (a.getCodigo().equalsIgnoreCase(codigo)) return a;
        return null;
    }

    public Reserva buscarReserva(String codigo) {
        for (Reserva r : reservas)
            if (r.getCodigo().equalsIgnoreCase(codigo)) return r;
        return null;
    }

    public Mantenimiento buscarMantenimiento(String codigo) {
        for (Mantenimiento m : mantenimientos)
            if (m.getCodigo().equalsIgnoreCase(codigo)) return m;
        return null;
    }

    // Programación funcional: filter + map + reduce sobre datos reales del sistema.
    public List<Pago> pagosPendientesPorDepartamento(String codigoDepartamento) {
        return pagos.stream()
                .filter(p -> p.getDepartamento().equalsIgnoreCase(codigoDepartamento))
                .filter(p -> p.getEstado().equalsIgnoreCase("Pendiente"))
                .toList();
    }

    public double totalPendiente(String codigoDepartamento) {
        return pagos.stream()
                .filter(p -> p.getDepartamento().equalsIgnoreCase(codigoDepartamento))
                .filter(p -> p.getEstado().equalsIgnoreCase("Pendiente"))
                .map(Pago::getMonto)
                .reduce(0.0, Double::sum);
    }
}
