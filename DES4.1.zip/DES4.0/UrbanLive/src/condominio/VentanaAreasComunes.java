package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaAreasComunes extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtMaxHoras;
    private JTextField txtSeparacion;
    private JTextArea txtReglas;
    private DefaultTableModel modelo;
    private JTable tabla;

    public VentanaAreasComunes() {
    	setModal(true);
        setTitle("Urban Live - Áreas comunes");
        setBounds(100, 100, 800, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Áreas comunes");
        titulo.setBounds(28, 18, 400, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Registra el área y define sus condiciones de reserva y reglas de uso.");
        ayuda.setBounds(30, 55, 720, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(null);
        panelDatos.setBackground(Estilos.FONDO);
        panelDatos.setBorder(new TitledBorder("Datos del área"));
        panelDatos.setBounds(25, 85, 735, 105);
        contentPane.add(panelDatos);

        JLabel lblCodigo = new JLabel("Código");
        lblCodigo.setBounds(15, 22, 160, 20);
        panelDatos.add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(15, 45, 160, 30);
        txtCodigo.setToolTipText("Ej.: A001");
        panelDatos.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(195, 22, 230, 20);
        panelDatos.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(195, 45, 230, 30);
        txtNombre.setToolTipText("Ej.: Piscina");
        panelDatos.add(txtNombre);
        txtNombre.setColumns(10);

        JPanel panelReglas = new JPanel();
        panelReglas.setLayout(null);
        panelReglas.setBackground(Estilos.FONDO);
        panelReglas.setBorder(new TitledBorder("Reglas del área común"));
        panelReglas.setBounds(25, 200, 735, 160);
        contentPane.add(panelReglas);

        JLabel lblMaxHoras = new JLabel("Máx. horas por reserva");
        lblMaxHoras.setBounds(15, 22, 190, 20);
        panelReglas.add(lblMaxHoras);

        txtMaxHoras = new JTextField();
        txtMaxHoras.setBounds(15, 45, 190, 30);
        txtMaxHoras.setToolTipText("Ej.: 3");
        panelReglas.add(txtMaxHoras);
        txtMaxHoras.setColumns(10);

        JLabel lblSeparacion = new JLabel("Horas mínimas entre reservas");
        lblSeparacion.setBounds(225, 22, 210, 20);
        panelReglas.add(lblSeparacion);

        txtSeparacion = new JTextField();
        txtSeparacion.setBounds(225, 45, 210, 30);
        txtSeparacion.setToolTipText("Ej.: 1");
        panelReglas.add(txtSeparacion);
        txtSeparacion.setColumns(10);

        JLabel lblReglas = new JLabel("Reglas adicionales");
        lblReglas.setBounds(455, 22, 180, 20);
        panelReglas.add(lblReglas);

        txtReglas = new JTextArea();
        txtReglas.setLineWrap(true);
        txtReglas.setWrapStyleWord(true);
        txtReglas.setToolTipText("Ej.: No ingresar alimentos. Uso exclusivo de 8:00 a 22:00.");
        JScrollPane reglasScroll = new JScrollPane(txtReglas);
        reglasScroll.setBounds(455, 45, 255, 90);
        panelReglas.add(reglasScroll);

        JLabel ejemplo = new JLabel("Ejemplo: Piscina = máximo 3 h, 1 h entre reservas y sin alimentos.");
        ejemplo.setBounds(15, 125, 420, 20);
        Estilos.subtitulo(ejemplo);
        panelReglas.add(ejemplo);

        JButton btnRegistrar = new JButton("REGISTRAR");
        btnRegistrar.setBounds(25, 380, 125, 34);
        btnRegistrar.setToolTipText("Guarda un área nueva");
        Estilos.boton(btnRegistrar);
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrar();
            }
        });
        contentPane.add(btnRegistrar);

        JButton btnBuscar = new JButton("BUSCAR");
        btnBuscar.setBounds(165, 380, 125, 34);
        btnBuscar.setToolTipText("Busca por código");
        Estilos.boton(btnBuscar);
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscar();
            }
        });
        contentPane.add(btnBuscar);

        JButton btnActualizar = new JButton("ACTUALIZAR");
        btnActualizar.setBounds(305, 380, 125, 34);
        btnActualizar.setToolTipText("Guarda cambios");
        Estilos.boton(btnActualizar);
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizar();
            }
        });
        contentPane.add(btnActualizar);

        JButton btnLimpiar = new JButton("LIMPIAR");
        btnLimpiar.setBounds(445, 380, 125, 34);
        btnLimpiar.setToolTipText("Vacía el formulario");
        Estilos.boton(btnLimpiar);
        btnLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        });
        contentPane.add(btnLimpiar);

        modelo = new DefaultTableModel(new Object[] {"Código", "Área", "Máx. horas", "Separación (h)", "Reglas"}, 0);
        tabla = new JTable(modelo);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(260);
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                    cargarFila();
                }
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(25, 430, 735, 115);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("VOLVER");
        btnVolver.setBounds(635, 565, 125, 34);
        btnVolver.setToolTipText("Regresa al menú principal");
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);

        actualizarTabla();
    }

    private void registrar() {
        try {
            String codigo = txtCodigo.getText().trim().toUpperCase();
            String nombre = txtNombre.getText().trim();
            String reglas = txtReglas.getText().trim();

            if (codigo.isEmpty() || nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Completa el código y el nombre del área.");
                return;
            }
            if (datos.buscarArea(codigo) != null) {
                JOptionPane.showMessageDialog(this, "Ese código ya existe. Usa otro, por ejemplo A001.");
                return;
            }

            int max = Integer.parseInt(txtMaxHoras.getText().trim());
            int separacion = Integer.parseInt(txtSeparacion.getText().trim());
            if (max <= 0 || separacion < 0) {
                JOptionPane.showMessageDialog(this, "Las horas deben ser valores válidos.");
                return;
            }

            datos.getAreas().add(FabricaEntidades.crearArea(codigo, nombre, max, separacion, reglas));
            actualizarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Área registrada con sus reglas.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Máximo de horas y separación deben ser números enteros.");
        }
    }

    private void buscar() {
        AreaComun a = datos.buscarArea(txtCodigo.getText().trim());
        if (a == null) {
            JOptionPane.showMessageDialog(this, "Área no encontrada.");
            return;
        }
        cargar(a);
    }

    private void actualizar() {
        AreaComun a = datos.buscarArea(txtCodigo.getText().trim());
        if (a == null) {
            JOptionPane.showMessageDialog(this, "Busca o selecciona un área.");
            return;
        }
        try {
            int max = Integer.parseInt(txtMaxHoras.getText().trim());
            int sep = Integer.parseInt(txtSeparacion.getText().trim());
            if (max <= 0 || sep < 0) {
                JOptionPane.showMessageDialog(this, "Las horas deben ser valores válidos.");
                return;
            }
            a.setNombre(txtNombre.getText().trim());
            a.setMaxHorasReserva(max);
            a.setHorasEntreReservas(sep);
            a.setReglas(txtReglas.getText().trim());
            actualizarTabla();
            JOptionPane.showMessageDialog(this, "Área y reglas actualizadas.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Revisa las horas ingresadas.");
        }
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        AreaComun a = datos.buscarArea(modelo.getValueAt(fila, 0).toString());
        if (a != null) {
            cargar(a);
        }
    }

    private void cargar(AreaComun a) {
        txtCodigo.setText(a.getCodigo());
        txtNombre.setText(a.getNombre());
        txtMaxHoras.setText(String.valueOf(a.getMaxHorasReserva()));
        txtSeparacion.setText(String.valueOf(a.getHorasEntreReservas()));
        txtReglas.setText(a.getReglas());
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (AreaComun a : datos.getAreas()) {
            modelo.addRow(new Object[] {a.getCodigo(), a.getNombre(), a.getMaxHorasReserva(), a.getHorasEntreReservas(), a.getReglas()});
        }
    }

    private void limpiar() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtMaxHoras.setText("");
        txtSeparacion.setText("");
        txtReglas.setText("");
        tabla.clearSelection();
    }
}
