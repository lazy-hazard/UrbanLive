package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class VentanaPagos extends JDialog {
    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JButton btnConsulta;
    private JButton btnAdmin;
    private JButton btnVolver;

    public VentanaPagos() {
    	setModal(true);
        setTitle("Urban Live - Pagos y deudas");
        setBounds(100, 100, 560, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Pagos y deudas");
        titulo.setBounds(30, 20, 360, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Elige cómo deseas ingresar:");
        ayuda.setBounds(30, 62, 420, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        btnConsulta = new JButton("1 - CONSULTAR Y PAGAR DEUDA / SERVICIOS");
        btnConsulta.setBounds(55, 115, 435, 52);
        Estilos.boton(btnConsulta);
        btnConsulta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaConsultaPagos().setVisible(true);
            }
        });
        contentPane.add(btnConsulta);

        btnAdmin = new JButton("2 - ADMINISTRAR PAGOS");
        btnAdmin.setBounds(55, 185, 435, 52);
        Estilos.boton(btnAdmin);
        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (Seguridad.solicitarAcceso(VentanaPagos.this)) {
                    new VentanaAdministrarPagos().setVisible(true);
                }
            }
        });
        contentPane.add(btnAdmin);

        btnVolver = new JButton("VOLVER");
        btnVolver.setBounds(355, 265, 135, 35);
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);
    }
}
