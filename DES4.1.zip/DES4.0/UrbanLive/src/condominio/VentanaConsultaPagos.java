package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class VentanaConsultaPagos extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtDepartamento;
    private DefaultTableModel modelo;
    private JTable tabla;
    private JLabel lblTotal;

    public VentanaConsultaPagos() {
    	setModal(true);
        setTitle("Urban Live - Consultar y pagar");
        setBounds(100, 100, 760, 525);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Consultar deuda / servicios");
        titulo.setBounds(28, 18, 430, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Ingresa únicamente tu código de departamento. Ejemplo: D001");
        ayuda.setBounds(30, 55, 650, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JLabel lblDepartamento = new JLabel("Código de departamento");
        lblDepartamento.setBounds(30, 95, 190, 20);
        contentPane.add(lblDepartamento);

        txtDepartamento = new JTextField();
        txtDepartamento.setBounds(30, 118, 200, 30);
        txtDepartamento.setToolTipText("Ej.: D001");
        contentPane.add(txtDepartamento);
        txtDepartamento.setColumns(10);

        JButton btnConsultar = new JButton("CONSULTAR");
        btnConsultar.setBounds(250, 118, 130, 30);
        Estilos.boton(btnConsultar);
        btnConsultar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                consultar();
            }
        });
        contentPane.add(btnConsultar);

        JButton btnPagar = new JButton("PAGAR SELECCIONADA");
        btnPagar.setBounds(400, 118, 180, 30);
        Estilos.boton(btnPagar);
        btnPagar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pagar();
            }
        });
        contentPane.add(btnPagar);

        lblTotal = new JLabel("Total pendiente: S/ 0.00");
        lblTotal.setBounds(30, 165, 300, 22);
        Estilos.subtitulo(lblTotal);
        contentPane.add(lblTotal);

        modelo = new DefaultTableModel(new Object[] {"Código", "Tipo", "Concepto", "Monto", "Estado"}, 0);
        tabla = new JTable(modelo);
        tabla.setToolTipText("Selecciona una deuda para pagarla");
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 200, 680, 200);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("VOLVER");
        btnVolver.setBounds(575, 425, 135, 35);
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);
    }

    private void consultar() {
        String dep = txtDepartamento.getText().trim().toUpperCase();
        if (datos.buscarDepartamento(dep) == null) {
            JOptionPane.showMessageDialog(this, "Departamento no encontrado.");
            return;
        }

        modelo.setRowCount(0);
        for (Pago p : datos.pagosPendientesPorDepartamento(dep)) {
            modelo.addRow(new Object[] {p.getCodigo(), p.getTipoOcupante(), p.getConcepto(), p.getMonto(), p.getEstado()});
        }
        double total = datos.totalPendiente(dep);
        lblTotal.setText(String.format("Total pendiente: S/ %.2f", total));
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay deudas pendientes para " + dep + ".");
        }
    }

    private void pagar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona una deuda de la tabla.");
            return;
        }
        String codigo = modelo.getValueAt(fila, 0).toString();
        Pago p = datos.buscarPago(codigo);
        if (p == null || !p.getEstado().equalsIgnoreCase("Pendiente")) {
            return;
        }

        int op = JOptionPane.showConfirmDialog(this,
                "¿Registrar el pago de S/ " + String.format("%.2f", p.getMonto()) + "?",
                "Confirmar pago", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            p.setEstado("Pagado");
            JOptionPane.showMessageDialog(this, "Pago registrado correctamente.");
            consultar();
        }
    }
}
