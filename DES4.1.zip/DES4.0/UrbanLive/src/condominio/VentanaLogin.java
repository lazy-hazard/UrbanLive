package condominio;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;

public class VentanaLogin extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel_1;
	private JComboBox cmbRol;
	private JLabel lblNewLabel_2;
	private JPasswordField txtContrasena;
	private JButton btnIngresar;
	private JLabel lblResultado;
	private JLabel lblNewLabel_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaLogin frame = new VentanaLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaLogin() {
		setResizable(false);
		setTitle("LOGIN");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		{
			lblNewLabel_1 = new JLabel("Rol:");
			lblNewLabel_1.setForeground(new Color(255, 255, 255));
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(28, 146, 71, 20);
			contentPane.add(lblNewLabel_1);
		}
		{
			cmbRol = new JComboBox();
			cmbRol.setModel(new DefaultComboBoxModel(new String[] {"Administrador", "Inquilino"}));
			cmbRol.setBounds(159, 146, 103, 20);
			contentPane.add(cmbRol);
		}
		{
			lblNewLabel_2 = new JLabel("Contraseña: ");
			lblNewLabel_2.setForeground(new Color(255, 255, 255));
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_2.setBounds(26, 173, 121, 20);
			contentPane.add(lblNewLabel_2);
		}
		{
			txtContrasena = new JPasswordField();
			txtContrasena.setBounds(159, 176, 103, 18);
			contentPane.add(txtContrasena);
		}
		{
			btnIngresar = new JButton("Ingresar");
			btnIngresar.addActionListener(this);
			btnIngresar.setBounds(159, 205, 84, 20);
			contentPane.add(btnIngresar);
		}
		{
			lblResultado = new JLabel("");
			lblResultado.setForeground(new Color(255, 255, 255));
			lblResultado.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblResultado.setBounds(10, 274, 321, 38);
			contentPane.add(lblResultado);
		}
		{
			lblNewLabel_3 = new JLabel("");
			lblNewLabel_3.setIcon(new ImageIcon(VentanaLogin.class.getResource("/imagenes/Urban_Live_JLabel_550x330.png")));
			lblNewLabel_3.setBounds(0, 0, 498, 325);
			contentPane.add(lblNewLabel_3);
		}

	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnIngresar) {
			do_btnIngresar_actionPerformed(e);
		}
	}
	protected void do_btnIngresar_actionPerformed(ActionEvent e) 
	{
		String rol = cmbRol.getSelectedItem().toString();
		String contrasena = new String(txtContrasena.getPassword());

		if (rol.equals("Administrador")) {

		    if (contrasena.equals("123")) {
		    	MenuPrincipal menu = new MenuPrincipal("Administrador");
		    	menu.setVisible(true);
		    	dispose();
		    } else {
		        lblResultado.setText("Contraseña incorrecta");
		    }

		} else if (rol.equals("Inquilino")) {

		    if (contrasena.equals("456")) {
		    	MenuPrincipal menu = new MenuPrincipal("Inquilino");
		    	menu.setVisible(true);
		    	dispose();
		    } else {
		        lblResultado.setText("Contraseña incorrecta");
		    }
		}
	}
}
