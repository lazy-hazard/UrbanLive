package condominio;

import java.awt.Component;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;

public final class Seguridad {
    public static final String CLAVE_ADMIN = "123";

    private Seguridad() { }

    public static boolean esAdministrador() {
        return Sesion.esAdministrador();
    }

    public static boolean validarAdministrador(Component padre) {
        if (Sesion.esAdministrador()) return true;
        JOptionPane.showMessageDialog(padre, "Esta operación requiere una sesión de administrador.");
        return false;
    }

    public static boolean validarDepartamento(Component padre, String departamento) {
        if (!Sesion.estaIniciada()) {
            JOptionPane.showMessageDialog(padre, "No hay una sesión iniciada.");
            return false;
        }
        if (Sesion.perteneceADepartamento(departamento)) return true;
        JOptionPane.showMessageDialog(padre, "No tienes acceso a los datos de otro departamento.");
        return false;
    }

    /** Compatibilidad con las ventanas antiguas que pedían una clave administrativa. */
    public static boolean solicitarAcceso(Component padre) {
        if (Sesion.esAdministrador()) return true;

        JPasswordField campo = new JPasswordField();
        int opcion = JOptionPane.showConfirmDialog(
                padre, campo, "Herramientas de administrador - Contraseña",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opcion != JOptionPane.OK_OPTION) return false;

        if (CLAVE_ADMIN.equals(new String(campo.getPassword()))) return true;
        JOptionPane.showMessageDialog(padre, "Contraseña incorrecta.");
        return false;
    }
}
