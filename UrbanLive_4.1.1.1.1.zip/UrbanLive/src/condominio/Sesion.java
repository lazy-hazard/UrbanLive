package condominio;

/**
 * Sesión actual de Urban Live. Mantiene el rol y, para residentes,
 * el departamento autenticado.
 */
public final class Sesion {
    public static final String ADMINISTRADOR = "Administrador";
    public static final String RESIDENTE = "Residente";

    private static String rol;
    private static String departamento;

    private Sesion() { }

    public static void iniciarAdministrador() {
        rol = ADMINISTRADOR;
        departamento = null;
    }

    public static void iniciarResidente(String codigoDepartamento) {
        rol = RESIDENTE;
        departamento = codigoDepartamento == null ? null : codigoDepartamento.trim().toUpperCase();
    }

    public static boolean estaIniciada() {
        return rol != null;
    }

    public static boolean esAdministrador() {
        return ADMINISTRADOR.equals(rol);
    }

    public static boolean esResidente() {
        return RESIDENTE.equals(rol);
    }

    public static String getRol() {
        return rol;
    }

    public static String getDepartamento() {
        return departamento;
    }

    public static boolean perteneceADepartamento(String codigo) {
        return esAdministrador() || (codigo != null && codigo.equalsIgnoreCase(departamento));
    }

    public static void cerrar() {
        rol = null;
        departamento = null;
    }
}
