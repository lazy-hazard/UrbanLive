package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaReservas extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");

    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtDepartamento;
    private JTextField txtArea;
    private JTextField txtFecha;
    private JTextField txtHora;
    private DefaultTableModel modelo;
    private JTable tabla;

    public VentanaReservas() {
    	setModal(true);
        setTitle("Urban Live - Reservas");
        setBounds(100, 100, 830, 625);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Reservas de áreas comunes");
        titulo.setBounds(28, 18, 450, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Ejemplo: R001 · D001 · A001 · 20/09/2026 · 18:00");
        ayuda.setBounds(30, 55, 720, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JLabel lblCodigo = new JLabel("Código");
        lblCodigo.setBounds(30, 90, 160, 20);
        contentPane.add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setEditable(false);
        txtCodigo.setBounds(30, 113, 190, 30);
        txtCodigo.setToolTipText("Ej.: R001");
        contentPane.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblDepartamento = new JLabel("Departamento");
        lblDepartamento.setBounds(270, 90, 160, 20);
        contentPane.add(lblDepartamento);

        txtDepartamento = new JTextField();
        txtDepartamento.setEditable(false);
        txtDepartamento.setBounds(270, 113, 190, 30);
        txtDepartamento.setToolTipText("Ej.: D001");
        contentPane.add(txtDepartamento);
        txtDepartamento.setColumns(10);
        if (Sesion.esResidente()) txtDepartamento.setText(Sesion.getDepartamento());

        JLabel lblArea = new JLabel("Código del área");
        lblArea.setBounds(510, 90, 160, 20);
        contentPane.add(lblArea);

        txtArea = new JTextField();
        txtArea.setBounds(510, 113, 190, 30);
        txtArea.setToolTipText("Ej.: A001");
        contentPane.add(txtArea);
        txtArea.setColumns(10);

        JLabel lblFecha = new JLabel("Fecha");
        lblFecha.setBounds(30, 155, 160, 20);
        contentPane.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(30, 178, 190, 30);
        txtFecha.setToolTipText("Ej.: 20/09/2026");
        contentPane.add(txtFecha);
        txtFecha.setColumns(10);

        JLabel lblHora = new JLabel("Hora de inicio");
        lblHora.setBounds(270, 155, 160, 20);
        contentPane.add(lblHora);

        txtHora = new JTextField();
        txtHora.setBounds(270, 178, 190, 30);
        txtHora.setToolTipText("Ej.: 18:00");
        contentPane.add(txtHora);
        txtHora.setColumns(10);

        JButton btnReservar = new JButton("RESERVAR");
        btnReservar.setBounds(510, 160, 110, 32);
        btnReservar.setToolTipText("Registra una reserva");
        Estilos.boton(btnReservar);
        btnReservar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reservar();
            }
        });
        contentPane.add(btnReservar);
        btnReservar.setEnabled(Sesion.esResidente());

        JButton btnCancelar = new JButton("CANCELAR");
        btnCancelar.setBounds(630, 160, 110, 32);
        btnCancelar.setToolTipText("Cancela la reserva seleccionada");
        Estilos.boton(btnCancelar);
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelar();
            }
        });
        contentPane.add(btnCancelar);

        JLabel nota = new JLabel("La duración se asigna automáticamente según el área. También se respeta el tiempo mínimo entre reservas.");
        nota.setBounds(30, 225, 710, 20);
        Estilos.subtitulo(nota);
        contentPane.add(nota);

        modelo = new DefaultTableModel(new Object[] {"Código", "Departamento", "Área", "Fecha", "Inicio", "Duración", "Fin"}, 0);
        tabla = new JTable(modelo);
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                    cargarFila();
                }
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 275, 710, 220);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("VOLVER");
        btnVolver.setBounds(630, 515, 110, 32);
        btnVolver.setToolTipText("Regresa al menú principal");
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);

        actualizarTabla();
        prepararNuevoCodigo();
    }

    private void prepararNuevoCodigo() {
        txtCodigo.setText(datos.siguienteCodigoReserva());
        if (Sesion.esResidente()) txtDepartamento.setText(Sesion.getDepartamento());
    }

    private void reservar() {
        if (!Sesion.esResidente()) {
            JOptionPane.showMessageDialog(this, "Solo un residente puede crear una reserva.");
            return;
        }
        String c = datos.siguienteCodigoReserva();
        String d = Sesion.getDepartamento();
        String a = txtArea.getText().trim().toUpperCase();
        String f = txtFecha.getText().trim();
        String h = txtHora.getText().trim();

        if (c.isEmpty() || d.isEmpty() || a.isEmpty() || f.isEmpty() || h.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos.");
            return;
        }
        if (datos.buscarReserva(c) != null) {
            JOptionPane.showMessageDialog(this, "Ese código de reserva ya existe.");
            return;
        }
        if (datos.buscarDepartamento(d) == null) {
            JOptionPane.showMessageDialog(this, "El departamento no existe.");
            return;
        }

        AreaComun area = datos.buscarArea(a);
        if (area == null) {
            JOptionPane.showMessageDialog(this, "El área no existe.");
            return;
        }

        try {
            LocalDate fecha = LocalDate.parse(f, FECHA);
            LocalTime inicio = LocalTime.parse(h, HORA);
            int duracion = area.getMaxHorasReserva();

            if (duracion <= 0) {
                JOptionPane.showMessageDialog(this, "El área no tiene una duración válida configurada.");
                return;
            }

            LocalTime fin = inicio.plusHours(duracion);
            if (fin.isBefore(inicio) || fin.equals(inicio)) {
                JOptionPane.showMessageDialog(this, "La reserva debe terminar el mismo día.");
                return;
            }

            for (Reserva r : datos.getReservas()) {
                if (!r.getArea().equalsIgnoreCase(a)) {
                    continue;
                }

                LocalDate fechaExistente = LocalDate.parse(r.getFecha(), FECHA);
                if (!fechaExistente.equals(fecha)) {
                    continue;
                }

                LocalTime inicioExistente = LocalTime.parse(r.getHora(), HORA);
                LocalTime finExistente = inicioExistente.plusHours(r.getDuracionHoras());
                int separacion = area.getHorasEntreReservas();

                boolean conflicto = inicio.isBefore(finExistente.plusHours(separacion))
                        && fin.plusHours(separacion).isAfter(inicioExistente);

                if (conflicto) {
                    JOptionPane.showMessageDialog(this,
                            "No se puede reservar ese horario. " + area.getNombre()
                            + " exige " + separacion + " hora(s) libres entre reservas.");
                    return;
                }
            }

            datos.getReservas().add(FabricaEntidades.crearReserva(c, d, a, f, h, duracion));
            actualizarTabla();
            limpiar();
            prepararNuevoCodigo();
            JOptionPane.showMessageDialog(this, "Reserva registrada correctamente con código " + c + ".");
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Usa fecha dd/MM/yyyy y hora HH:mm. Ej.: 20/09/2026 y 18:00");
        }
    }

    private void cancelar() {
        Reserva r = datos.buscarReserva(txtCodigo.getText().trim());
        if (r != null && !Sesion.perteneceADepartamento(r.getDepartamento())) {
            JOptionPane.showMessageDialog(this, "No puedes cancelar una reserva de otro departamento.");
            return;
        }
        if (r == null) {
            JOptionPane.showMessageDialog(this, "Selecciona o escribe una reserva existente.");
            return;
        }
        datos.getReservas().remove(r);
        actualizarTabla();
        limpiar();
        JOptionPane.showMessageDialog(this, "Reserva cancelada.");
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        txtCodigo.setText(modelo.getValueAt(fila, 0).toString());
        txtDepartamento.setText(modelo.getValueAt(fila, 1).toString());
        txtArea.setText(modelo.getValueAt(fila, 2).toString());
        txtFecha.setText(modelo.getValueAt(fila, 3).toString());
        txtHora.setText(modelo.getValueAt(fila, 4).toString());
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Reserva r : datos.getReservas()) {
            if (Sesion.esResidente() && !r.getDepartamento().equalsIgnoreCase(Sesion.getDepartamento())) continue;
            String fin = "";
            try {
                fin = LocalTime.parse(r.getHora(), HORA).plusHours(r.getDuracionHoras()).format(HORA);
            } catch (Exception ignored) {
                fin = "";
            }
            modelo.addRow(new Object[] {r.getCodigo(), r.getDepartamento(), r.getArea(), r.getFecha(), r.getHora(), r.getDuracionHoras(), fin});
        }
    }

    private void limpiar() {
        txtCodigo.setText(datos.siguienteCodigoReserva());
        if (Sesion.esResidente()) txtDepartamento.setText(Sesion.getDepartamento());
        txtArea.setText("");
        txtFecha.setText("");
        txtHora.setText("");
        tabla.clearSelection();
    }
}
