package condominio;

public class Departamento {
    private String codigo;
    private int numero;
    private int piso;
    private String tipoOcupante;
    private double cuota;
    private String contrasena;
    private boolean contrasenaInicial;

    public Departamento(String codigo, int numero, int piso, String tipoOcupante, double cuota) {
        this(codigo, numero, piso, tipoOcupante, cuota, codigo, true);
    }

    public Departamento(String codigo, int numero, int piso, String tipoOcupante, double cuota,
                         String contrasena, boolean contrasenaInicial) {
        this.codigo = codigo;
        this.numero = numero;
        this.piso = piso;
        this.tipoOcupante = tipoOcupante;
        this.cuota = cuota;
        this.contrasena = contrasena;
        this.contrasenaInicial = contrasenaInicial;
    }

    public String getCodigo() { return codigo; }
    public int getNumero() { return numero; }
    public int getPiso() { return piso; }
    public String getTipoOcupante() { return tipoOcupante; }
    public double getCuota() { return cuota; }
    public boolean validarContrasena(String clave) { return contrasena != null && contrasena.equals(clave); }
    public boolean isContrasenaInicial() { return contrasenaInicial; }

    public void setNumero(int numero) { this.numero = numero; }
    public void setPiso(int piso) { this.piso = piso; }
    public void setTipoOcupante(String tipoOcupante) { this.tipoOcupante = tipoOcupante; }
    public void setCuota(double cuota) { this.cuota = cuota; }

    public void cambiarContrasena(String nuevaContrasena) {
        this.contrasena = nuevaContrasena;
        this.contrasenaInicial = false;
    }

    public void restablecerContrasenaInicial() {
        this.contrasena = codigo;
        this.contrasenaInicial = true;
    }

    public void establecerContrasenaAdministrador(String nuevaContrasena) {
        if (nuevaContrasena == null || nuevaContrasena.trim().isEmpty()) {
            throw new IllegalArgumentException("La contraseña no puede estar vacía.");
        }
        this.contrasena = nuevaContrasena;
        this.contrasenaInicial = false;
    }
}
