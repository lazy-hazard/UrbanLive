package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;

public class MenuPrincipal extends JFrame implements ActionListener, MouseListener {
    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JButton btnDepartamentos, btnPagos, btnAreas, btnReservas, btnMantenimiento;
    private JButton btnSalir, btnCreditos, btnCambiarClave;
    private String rol;

    public static void main(String[] args) { }

    public MenuPrincipal(String rol) {
        this.rol = rol;
        setTitle("Urban Live");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setBounds(100, 100, 810, 613);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(24, 34, 24, 34));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitulo = new JLabel("URBAN LIVE");
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(456, 54, 297, 38);
        Estilos.titulogrande(lblTitulo);
        contentPane.add(lblTitulo);

        JLabel lblSubtitulo = new JLabel("Administrador".equals(rol)
                ? "Panel administrativo"
                : "Sesión: " + Sesion.getDepartamento());
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setBounds(438, 117, 329, 24);
        Estilos.subtitulomenu(lblSubtitulo);
        contentPane.add(lblSubtitulo);

        btnDepartamentos = crearBoton("DEPARTAMENTOS", 36, 47, e -> abrirDepartamentos());
        btnAreas = crearBoton("ÁREAS COMUNES", 36, 117, e -> abrirAreas());
        btnMantenimiento = crearBoton("MANTENIMIENTO", 36, 187, e -> abrirMantenimiento());
        btnPagos = crearBoton("PAGOS Y DEUDAS", 36, 257, e -> abrirPagos());
        btnReservas = crearBoton("RESERVAS", 36, 327, e -> abrirReservas());
        btnCreditos = crearBoton("CREDITOS", 36, 397, e -> abrirCreditos());
        btnSalir = crearBoton("SALIR", 36, 467, e -> cerrarSesion());

        btnCambiarClave = crearBoton("CAMBIAR CONTRASEÑA", 438, 160, e -> cambiarContrasena());

        JLabel imagen = new JLabel("");
        imagen.setIcon(new ImageIcon(MenuPrincipal.class.getResource("/imagenes/b842316b-b14f-40df-819d-b704c479ef23.png")));
        imagen.setHorizontalAlignment(SwingConstants.CENTER);
        imagen.setBounds(475, 257, 255, 255);
        contentPane.add(imagen);

        JLabel fondo = new JLabel("");
        fondo.setIcon(new ImageIcon(MenuPrincipal.class.getResource("/imagenes/fondo.jpg")));
        fondo.setBounds(0, 0, 794, 574);
        contentPane.add(fondo);

        if (Sesion.esResidente()) {
            btnDepartamentos.setEnabled(false);
            btnCreditos.setEnabled(false);
            // Las ventanas también validan el rol; esto solo mejora la experiencia visual.
        } else {
            btnCambiarClave.setVisible(false);
        }
    }

    private JButton crearBoton(String texto, int x, int y, ActionListener listener) {
        JButton b = new JButton(texto);
        b.setBounds(x, y, 235, 52);
        Estilos.botonazul(b);
        b.addActionListener(listener);
        contentPane.add(b);
        return b;
    }

    private void abrirDepartamentos() {
        if (Seguridad.validarAdministrador(this)) new VentanaDepartamentos().setVisible(true);
    }
    private void abrirAreas() { new VentanaAreasComunes().setVisible(true); }
    private void abrirMantenimiento() { new VentanaMantenimiento().setVisible(true); }
    private void abrirPagos() { new VentanaPagos().setVisible(true); }
    private void abrirReservas() { new VentanaReservas().setVisible(true); }
    private void abrirCreditos() {
        if (Seguridad.validarAdministrador(this)) {
            new VentanaCreditos().setVisible(true);
            new VentanaDesarrolladores().setVisible(true);
        }
    }

    private void cambiarContrasena() {
        if (!Sesion.esResidente()) return;
        Departamento d = DatosCondominio.getInstancia().buscarDepartamento(Sesion.getDepartamento());
        if (d == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el departamento de la sesión.");
            return;
        }

        javax.swing.JPasswordField actual = new javax.swing.JPasswordField();
        javax.swing.JPasswordField nueva = new javax.swing.JPasswordField();
        javax.swing.JPasswordField confirmar = new javax.swing.JPasswordField();
        JPanel panel = new JPanel(new java.awt.GridLayout(3, 2, 6, 6));
        panel.add(new JLabel("Contraseña actual:")); panel.add(actual);
        panel.add(new JLabel("Nueva contraseña:")); panel.add(nueva);
        panel.add(new JLabel("Confirmar nueva:")); panel.add(confirmar);

        int op = JOptionPane.showConfirmDialog(this, panel, "Cambiar contraseña",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (op != JOptionPane.OK_OPTION) return;

        String a = new String(actual.getPassword());
        String n = new String(nueva.getPassword());
        String c = new String(confirmar.getPassword());
        if (!d.validarContrasena(a)) {
            JOptionPane.showMessageDialog(this, "La contraseña actual no es correcta.");
            return;
        }
        if (n.isEmpty()) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña no puede estar vacía.");
            return;
        }
        if (!n.equals(c)) {
            JOptionPane.showMessageDialog(this, "La confirmación no coincide.");
            return;
        }
        if (n.equals(a)) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña debe ser diferente.");
            return;
        }
        d.cambiarContrasena(n);
        JOptionPane.showMessageDialog(this, "Contraseña actualizada. Estado: Cambiada.");
    }

    private void cerrarSesion() {
        Sesion.cerrar();
        new VentanaLogin().setVisible(true);
        dispose();
    }

    public void actionPerformed(ActionEvent e) { }
    public void mouseClicked(MouseEvent e) { }
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }
    public void mousePressed(MouseEvent e) { }
    public void mouseReleased(MouseEvent e) { }
}
