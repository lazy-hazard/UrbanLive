package condominio;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

public class VentanaLogin extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> cmbRol;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JLabel lblResultado;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                new VentanaLogin().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VentanaLogin() {
        setResizable(false);
        setTitle("LOGIN - Urban Live");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 512, 362);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblRol = new JLabel("Rol:");
        lblRol.setForeground(Color.WHITE);
        lblRol.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblRol.setBounds(28, 120, 100, 20);
        contentPane.add(lblRol);

        cmbRol = new JComboBox<>();
        cmbRol.setModel(new DefaultComboBoxModel<>(new String[] {"Administrador", "Residente"}));
        cmbRol.setBounds(159, 120, 140, 22);
        cmbRol.addActionListener(e -> actualizarCampos());
        contentPane.add(cmbRol);

        JLabel lblUsuario = new JLabel("Usuario / Departamento:");
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblUsuario.setBounds(28, 151, 170, 20);
        contentPane.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(205, 151, 120, 22);
        txtUsuario.setToolTipText("Residente: código del departamento, por ejemplo D101");
        contentPane.add(txtUsuario);

        JLabel lblClave = new JLabel("Contraseña:");
        lblClave.setForeground(Color.WHITE);
        lblClave.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblClave.setBounds(28, 181, 121, 20);
        contentPane.add(lblClave);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(159, 184, 166, 20);
        contentPane.add(txtContrasena);

        btnIngresar = new JButton("Ingresar");
        btnIngresar.addActionListener(this);
        btnIngresar.setBounds(159, 216, 100, 28);
        contentPane.add(btnIngresar);

        lblResultado = new JLabel("");
        lblResultado.setForeground(Color.WHITE);
        lblResultado.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblResultado.setBounds(28, 267, 430, 30);
        contentPane.add(lblResultado);

        JLabel fondo = new JLabel("");
        fondo.setIcon(new ImageIcon(VentanaLogin.class.getResource("/imagenes/Urban_Live_JLabel_550x330.png")));
        fondo.setBounds(0, 0, 498, 325);
        contentPane.add(fondo);

        actualizarCampos();
    }

    private void actualizarCampos() {
        boolean admin = "Administrador".equals(cmbRol.getSelectedItem());
        txtUsuario.setVisible(!admin);
        if (admin) {
            txtUsuario.setText("ADMIN");
        } else {
            txtUsuario.setText("");
            txtUsuario.requestFocusInWindow();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnIngresar) do_btnIngresar_actionPerformed(e);
    }

    protected void do_btnIngresar_actionPerformed(ActionEvent e) {
        String rol = cmbRol.getSelectedItem().toString();
        String clave = new String(txtContrasena.getPassword());

        if ("Administrador".equals(rol)) {
            if (Seguridad.CLAVE_ADMIN.equals(clave)) {
                Sesion.iniciarAdministrador();
                new MenuPrincipal(Sesion.ADMINISTRADOR).setVisible(true);
                dispose();
            } else {
                lblResultado.setText("Contraseña incorrecta");
            }
            return;
        }

        String codigo = txtUsuario.getText().trim().toUpperCase();
        Departamento d = DatosCondominio.getInstancia().buscarDepartamento(codigo);
        if (d == null) {
            lblResultado.setText("Departamento no encontrado");
            return;
        }
        if (!d.validarContrasena(clave)) {
            lblResultado.setText("Contraseña incorrecta");
            return;
        }

        Sesion.iniciarResidente(d.getCodigo());
        new MenuPrincipal(Sesion.RESIDENTE).setVisible(true);
        dispose();
    }
}
