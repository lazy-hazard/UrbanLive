package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JPopupMenu;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaDepartamentos extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtCodigo, txtNumero, txtPiso, txtCuota;
    private JComboBox<String> comboTipo;
    private DefaultTableModel modelo;
    private javax.swing.JTable tabla;
    private JPopupMenu sugerencias;
    private JList<String> listaSugerencias;

    public VentanaDepartamentos() {
        setModal(true);
        setTitle("Urban Live - Departamentos");
        setBounds(100, 100, 790, 625);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Gestión de departamentos");
        titulo.setBounds(28, 18, 400, 35); Estilos.titulo(titulo); contentPane.add(titulo);
        JLabel ayuda = new JLabel("Ejemplo: D101 · N.º 101 · Piso 1 · Inquilino · Cuota 300.00");
        ayuda.setBounds(30, 55, 700, 22); Estilos.subtitulo(ayuda); contentPane.add(ayuda);

        JLabel lblCodigo = new JLabel("Código"); lblCodigo.setBounds(30, 90, 140, 20); contentPane.add(lblCodigo);
        txtCodigo = new JTextField(); txtCodigo.setBounds(30, 113, 190, 30);
        txtCodigo.setToolTipText("Escribe D1 para ver D101, D102..."); contentPane.add(txtCodigo);
        txtCodigo.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { mostrarSugerencias(); }
        });

        JLabel lblNumero = new JLabel("Número"); lblNumero.setBounds(270, 90, 140, 20); contentPane.add(lblNumero);
        txtNumero = new JTextField(); txtNumero.setBounds(270, 113, 190, 30); contentPane.add(txtNumero);

        JLabel lblPiso = new JLabel("Piso"); lblPiso.setBounds(510, 90, 140, 20); contentPane.add(lblPiso);
        txtPiso = new JTextField(); txtPiso.setBounds(510, 113, 190, 30); contentPane.add(txtPiso);

        JLabel lblTipo = new JLabel("Ocupación"); lblTipo.setBounds(30, 155, 120, 20); contentPane.add(lblTipo);
        comboTipo = new JComboBox<>(new String[] {"Propietario", "Inquilino"});
        comboTipo.setBounds(30, 178, 190, 30); contentPane.add(comboTipo);

        JLabel lblCuota = new JLabel("Cuota mensual"); lblCuota.setBounds(270, 155, 140, 20); contentPane.add(lblCuota);
        txtCuota = new JTextField(); txtCuota.setBounds(270, 178, 190, 30); contentPane.add(txtCuota);

        JButton btnRegistrar = boton("REGISTRAR", 510, 155, e -> registrar());
        JButton btnBuscar = boton("BUSCAR", 630, 155, e -> buscar());
        JButton btnActualizar = boton("ACTUALIZAR", 510, 195, e -> actualizar());
        JButton btnLimpiar = boton("LIMPIAR", 630, 195, e -> limpiar());
        JButton btnClave = boton("CAMBIAR CLAVE", 510, 235, e -> cambiarClave());

        modelo = new DefaultTableModel(new Object[] {"Código", "Número", "Piso", "Ocupación", "Cuota", "Estado clave"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabla = new javax.swing.JTable(modelo);
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) cargarFila();
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 275, 710, 220); contentPane.add(scroll);

        JButton btnVolver = boton("VOLVER", 630, 515, e -> dispose());

        sugerencias = new JPopupMenu();
        listaSugerencias = new JList<>();
        listaSugerencias.setVisibleRowCount(5);
        listaSugerencias.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && listaSugerencias.getSelectedValue() != null) {
                txtCodigo.setText(listaSugerencias.getSelectedValue());
                sugerencias.setVisible(false);
                buscar();
            }
        });
        sugerencias.add(new JScrollPane(listaSugerencias));
        actualizarTabla();
    }

    private JButton boton(String texto, int x, int y, ActionListener a) {
        JButton b = new JButton(texto); b.setBounds(x, y, texto.equals("RESTABLECER CLAVE") ? 230 : 110, 32);
        Estilos.boton(b); b.addActionListener(a); contentPane.add(b); return b;
    }

    private void mostrarSugerencias() {
        String prefijo = txtCodigo.getText().trim();
        if (prefijo.isEmpty()) { sugerencias.setVisible(false); return; }
        List<Departamento> encontrados = datos.buscarDepartamentosPorPrefijo(prefijo);
        if (encontrados.isEmpty()) { sugerencias.setVisible(false); return; }
        String[] valores = encontrados.stream().map(Departamento::getCodigo).toArray(String[]::new);
        listaSugerencias.setModel(new javax.swing.DefaultListModel<>());
        javax.swing.DefaultListModel<String> m = (javax.swing.DefaultListModel<String>) listaSugerencias.getModel();
        for (String v : valores) m.addElement(v);
        sugerencias.show(txtCodigo, 0, txtCodigo.getHeight());
    }

    private void registrar() {
        if (!Seguridad.validarAdministrador(this)) return;
        try {
            String codigo = txtCodigo.getText().trim().toUpperCase();
            if (codigo.isEmpty() || datos.buscarDepartamento(codigo) != null) {
                JOptionPane.showMessageDialog(this, "Usa un código nuevo. Ejemplo: D101"); return;
            }
            Departamento d = FabricaEntidades.crearDepartamento(codigo,
                    Integer.parseInt(txtNumero.getText().trim()),
                    Integer.parseInt(txtPiso.getText().trim()),
                    comboTipo.getSelectedItem().toString(),
                    Double.parseDouble(txtCuota.getText().trim()));
            datos.getDepartamentos().add(d);
            actualizarTabla(); limpiar();
            JOptionPane.showMessageDialog(this, "Departamento registrado. Contraseña inicial: el mismo código del departamento.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Número y piso deben ser enteros; la cuota debe ser numérica.");
        }
    }

    private void buscar() {
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) { JOptionPane.showMessageDialog(this, "Departamento no encontrado."); return; }
        cargarDepartamento(d);
    }

    private void actualizar() {
        if (!Seguridad.validarAdministrador(this)) return;
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) { JOptionPane.showMessageDialog(this, "Busca o selecciona un departamento."); return; }
        try {
            d.setNumero(Integer.parseInt(txtNumero.getText().trim()));
            d.setPiso(Integer.parseInt(txtPiso.getText().trim()));
            d.setTipoOcupante(comboTipo.getSelectedItem().toString());
            d.setCuota(Double.parseDouble(txtCuota.getText().trim()));
            actualizarTabla(); JOptionPane.showMessageDialog(this, "Departamento actualizado.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Revisa número, piso y cuota.");
        }
    }

    private void restablecerClave() {
        if (!Seguridad.validarAdministrador(this)) return;
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) { JOptionPane.showMessageDialog(this, "Selecciona o busca un departamento."); return; }
        d.restablecerContrasenaInicial();
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Contraseña restablecida al código " + d.getCodigo() + ". Estado: Inicial.");
    }

    private void cambiarClave() {
        if (!Seguridad.validarAdministrador(this)) return;
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) {
            JOptionPane.showMessageDialog(this, "Selecciona o busca un departamento.");
            return;
        }
        JPasswordField campo = new JPasswordField();
        int op = JOptionPane.showConfirmDialog(this, campo,
                "Nueva contraseña para " + d.getCodigo(),
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (op != JOptionPane.OK_OPTION) return;
        String nueva = new String(campo.getPassword());
        if (nueva.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La contraseña no puede estar vacía.");
            return;
        }
        d.establecerContrasenaAdministrador(nueva);
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Contraseña actualizada. Estado: Cambiada.");
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow(); if (fila < 0) return;
        Departamento d = datos.buscarDepartamento(modelo.getValueAt(fila, 0).toString());
        if (d != null) cargarDepartamento(d);
    }

    private void cargarDepartamento(Departamento d) {
        txtCodigo.setText(d.getCodigo()); txtNumero.setText(String.valueOf(d.getNumero()));
        txtPiso.setText(String.valueOf(d.getPiso())); comboTipo.setSelectedItem(d.getTipoOcupante());
        txtCuota.setText(String.valueOf(d.getCuota()));
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Departamento d : datos.getDepartamentos())
            modelo.addRow(new Object[] {d.getCodigo(), d.getNumero(), d.getPiso(), d.getTipoOcupante(),
                    d.getCuota(), d.isContrasenaInicial() ? "Inicial" : "Cambiada"});
    }

    private void limpiar() {
        txtCodigo.setText(""); txtNumero.setText(""); txtPiso.setText(""); txtCuota.setText("");
        comboTipo.setSelectedIndex(0); tabla.clearSelection(); sugerencias.setVisible(false);
    }
}
