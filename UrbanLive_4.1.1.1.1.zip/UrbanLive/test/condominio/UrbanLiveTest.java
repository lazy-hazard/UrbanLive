package condominio;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UrbanLiveTest {
    private DatosCondominio datos;

    @BeforeEach
    void preparar() {
        datos = DatosCondominio.getInstancia();
        datos.getDepartamentos().clear();
        datos.getPagos().clear();
        datos.getAreas().clear();
        datos.getReservas().clear();
        datos.getMantenimientos().clear();
        Sesion.cerrar();
    }

    @Test
    void registraYBuscaDepartamento() {
        Departamento d = FabricaEntidades.crearDepartamento("D001", 101, 1, "Inquilino", 300.0);
        datos.getDepartamentos().add(d);

        assertNotNull(datos.buscarDepartamento("D001"));
        assertEquals(101, datos.buscarDepartamento("D001").getNumero());
    }

    @Test
    void calculaTotalDeDeudasPendientes() {
        Departamento d = FabricaEntidades.crearDepartamento("D001", 101, 1, "Inquilino", 300.0);
        datos.getDepartamentos().add(d);
        datos.getPagos().add(FabricaEntidades.crearDeuda("P001", d, "Cuota mensual", 300.0));
        datos.getPagos().add(FabricaEntidades.crearDeuda("P002", d, "Agua", 80.0));
        datos.buscarPago("P002").setEstado("Pagado");

        assertEquals(300.0, datos.totalPendiente("D001"), 0.001);
        assertEquals(1, datos.pagosPendientesPorDepartamento("D001").size());
    }

    @Test
    void conservaReglasDelAreaComun() {
        AreaComun piscina = FabricaEntidades.crearArea(
                "A001", "Piscina", 3, 1, "No ingresar alimentos");
        datos.getAreas().add(piscina);

        AreaComun resultado = datos.buscarArea("A001");
        assertEquals(3, resultado.getMaxHorasReserva());
        assertEquals(1, resultado.getHorasEntreReservas());
        assertEquals("No ingresar alimentos", resultado.getReglas());
    }
    @Test
    void creaDepartamentoConContrasenaInicialYPermiteCambiarla() {
        Departamento d = FabricaEntidades.crearDepartamento("D101", 101, 1, "Inquilino", 300.0);
        assertTrue(d.validarContrasena("D101"));
        assertTrue(d.isContrasenaInicial());

        d.cambiarContrasena("Nueva123");
        assertFalse(d.validarContrasena("D101"));
        assertTrue(d.validarContrasena("Nueva123"));
        assertFalse(d.isContrasenaInicial());
    }

    @Test
    void buscaDepartamentosPorPrefijoSobreLosDatosReales() {
        DatosCondominio datos = DatosCondominio.getInstancia();
        datos.getDepartamentos().add(FabricaEntidades.crearDepartamento("D101", 101, 1, "Inquilino", 300));
        datos.getDepartamentos().add(FabricaEntidades.crearDepartamento("D102", 102, 1, "Inquilino", 300));
        datos.getDepartamentos().add(FabricaEntidades.crearDepartamento("D201", 201, 2, "Inquilino", 300));

        assertEquals(2, datos.buscarDepartamentosPorPrefijo("D1").size());
        assertEquals(1, datos.buscarDepartamentosPorPrefijo("D2").size());
    }

    @Test
    void generaCodigosDeReservaSinDuplicados() {
        DatosCondominio datos = DatosCondominio.getInstancia();
        datos.getReservas().add(FabricaEntidades.crearReserva("R001", "D101", "A001", "01/01/2027", "10:00", 1));
        datos.getReservas().add(FabricaEntidades.crearReserva("R003", "D101", "A001", "02/01/2027", "10:00", 1));

        assertEquals("R004", datos.siguienteCodigoReserva());
    }

    @Test
    void sesionResidenteAislaElDepartamento() {
        Sesion.iniciarResidente("D101");
        assertTrue(Sesion.esResidente());
        assertTrue(Sesion.perteneceADepartamento("D101"));
        assertFalse(Sesion.perteneceADepartamento("D102"));
        Sesion.cerrar();
    }

}
