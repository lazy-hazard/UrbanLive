package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaMantenimiento extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtLugar;
    private JTextField txtDescripcion;
    private JComboBox<String> comboEstado;
    private DefaultTableModel modelo;
    private JTable tabla;

    public VentanaMantenimiento() {
    	setModal(true);
        setTitle("Urban Live - Mantenimiento");
        setBounds(100, 100, 780, 590);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Mantenimiento");
        titulo.setBounds(28, 18, 400, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Ejemplo: M001 · Departamento D001 · Fuga de agua · Pendiente");
        ayuda.setBounds(30, 55, 680, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JLabel lblCodigo = new JLabel("Código");
        lblCodigo.setBounds(30, 90, 140, 20);
        contentPane.add(lblCodigo);

        txtCodigo = new JTextField();
        AutoCompletar.instalar(txtCodigo, () -> datos.sugerenciasMantenimientos());
        txtCodigo.setBounds(30, 113, 190, 30);
        txtCodigo.setToolTipText("Ej.: M001");
        contentPane.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblLugar = new JLabel("Lugar");
        lblLugar.setBounds(270, 90, 140, 20);
        contentPane.add(lblLugar);

        txtLugar = new JTextField();
        txtLugar.setBounds(270, 113, 190, 30);
        txtLugar.setToolTipText("Ej.: Departamento D001");
        contentPane.add(txtLugar);
        txtLugar.setColumns(10);

        JLabel lblDescripcion = new JLabel("Descripción");
        lblDescripcion.setBounds(30, 155, 140, 20);
        contentPane.add(lblDescripcion);

        txtDescripcion = new JTextField();
        txtDescripcion.setBounds(30, 178, 430, 30);
        txtDescripcion.setToolTipText("Ej.: Fuga de agua en cocina");
        contentPane.add(txtDescripcion);
        txtDescripcion.setColumns(10);

        JLabel lblEstado = new JLabel("Estado");
        lblEstado.setBounds(510, 90, 100, 20);
        contentPane.add(lblEstado);

        comboEstado = new JComboBox<String>(new String[] {"Pendiente", "En proceso", "Terminado"});
        comboEstado.setBounds(510, 113, 200, 30);
        comboEstado.setToolTipText("Selecciona el avance del mantenimiento");
        contentPane.add(comboEstado);

        JButton btnRegistrar = new JButton("REGISTRAR");
        btnRegistrar.setBounds(510, 170, 110, 32);
        btnRegistrar.setToolTipText("Guarda un mantenimiento nuevo");
        Estilos.boton(btnRegistrar);
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrar();
            }
        });
        contentPane.add(btnRegistrar);

        JButton btnBuscar = new JButton("BUSCAR");
        btnBuscar.setBounds(630, 170, 110, 32);
        btnBuscar.setToolTipText("Busca por código");
        Estilos.boton(btnBuscar);
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscar();
            }
        });
        contentPane.add(btnBuscar);

        JButton btnActualizar = new JButton("ACTUALIZAR");
        btnActualizar.setBounds(510, 210, 110, 32);
        btnActualizar.setToolTipText("Guarda los cambios");
        Estilos.boton(btnActualizar);
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizar();
            }
        });
        contentPane.add(btnActualizar);

        JButton btnLimpiar = new JButton("LIMPIAR");
        btnLimpiar.setBounds(630, 210, 110, 32);
        btnLimpiar.setToolTipText("Vacía el formulario");
        Estilos.boton(btnLimpiar);
        btnLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        });
        contentPane.add(btnLimpiar);

        modelo = new DefaultTableModel(new Object[] {"Código", "Lugar", "Descripción", "Estado"}, 0);
        tabla = new JTable(modelo);
        tabla.setToolTipText("Haz clic en una fila para cargar sus datos");
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                    cargarFila();
                }
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 270, 680, 200);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("REGRESAR");
        btnVolver.setBounds(600, 490, 110, 32);
        btnVolver.setToolTipText("Regresa al menú principal");
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);

        actualizarTabla();
    }

    private void registrar() {
        String c = txtCodigo.getText().trim().toUpperCase();
        if (c.isEmpty() || txtLugar.getText().isBlank() || datos.buscarMantenimiento(c) != null) {
            JOptionPane.showMessageDialog(this, "Completa los datos con un código nuevo. Ejemplo: M001");
            return;
        
        }

        datos.getMantenimientos().add(FabricaEntidades.crearMantenimiento(
                c,
                txtLugar.getText().trim(),
                txtDescripcion.getText().trim(),
                comboEstado.getSelectedItem().toString()));
        actualizarTabla();
        limpiar();
        JOptionPane.showMessageDialog(this, "Mantenimiento registrado.");
    }

    private void buscar() {
        if (txtCodigo.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Escribe un código. Ejemplo: M001");
            return;
        }
        Mantenimiento m = datos.buscarMantenimiento(txtCodigo.getText().trim());
        if (m == null) {
            JOptionPane.showMessageDialog(this, "Registro no encontrado.");
            return;
        }
        cargarMantenimiento(m);
    }

    private void actualizar() {
        Mantenimiento m = datos.buscarMantenimiento(txtCodigo.getText().trim());
        if (m == null) {
            JOptionPane.showMessageDialog(this, "Busca o selecciona primero un registro existente.");
            return;
        }
        m.setLugar(txtLugar.getText().trim());
        m.setDescripcion(txtDescripcion.getText().trim());
        m.setEstado(comboEstado.getSelectedItem().toString());
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Mantenimiento actualizado.");
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        Mantenimiento m = datos.buscarMantenimiento(modelo.getValueAt(fila, 0).toString());
        if (m != null) {
            cargarMantenimiento(m);
        }
    }

    private void cargarMantenimiento(Mantenimiento m) {
        txtCodigo.setText(m.getCodigo());
        txtLugar.setText(m.getLugar());
        txtDescripcion.setText(m.getDescripcion());
        comboEstado.setSelectedItem(m.getEstado());
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Mantenimiento m : datos.getMantenimientos()) {
            modelo.addRow(new Object[] {m.getCodigo(), m.getLugar(), m.getDescripcion(), m.getEstado()});
        }
    }

    private void limpiar() {
        txtCodigo.setText("");
        txtLugar.setText("");
        txtDescripcion.setText("");
        comboEstado.setSelectedIndex(0);
        tabla.clearSelection();
    }
}
