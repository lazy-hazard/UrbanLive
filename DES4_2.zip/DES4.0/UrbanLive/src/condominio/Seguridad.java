package condominio;

import java.awt.Component;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;

public class Seguridad {
    public static final String CLAVE_ADMIN = "ADMIN123";

    private Seguridad() { }

    public static boolean solicitarAcceso(Component padre) {
        JPasswordField campo = new JPasswordField();
        int opcion = JOptionPane.showConfirmDialog(
                padre,
                campo,
                "Herramientas de administrador - Contraseña",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (opcion != JOptionPane.OK_OPTION) return false;

        if (CLAVE_ADMIN.equals(new String(campo.getPassword()))) return true;

        JOptionPane.showMessageDialog(padre, "Contraseña incorrecta.");
        return false;
    }
}
