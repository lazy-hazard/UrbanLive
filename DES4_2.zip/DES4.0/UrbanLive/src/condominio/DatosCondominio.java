package condominio;

import java.util.ArrayList;
import java.util.List;

public class DatosCondominio {
    private static final DatosCondominio INSTANCIA = new DatosCondominio();

    private final ArrayList<Departamento> departamentos = new ArrayList<>();
    private final ArrayList<Pago> pagos = new ArrayList<>();
    private final ArrayList<AreaComun> areas = new ArrayList<>();
    private final ArrayList<Reserva> reservas = new ArrayList<>();
    private final ArrayList<Mantenimiento> mantenimientos = new ArrayList<>();

    private String usuarioActual = "";

    private DatosCondominio() { sembrar(); }

    private void sembrar() {
        departamentos.add(FabricaEntidades.crearDepartamento("D101", 101, 1, "Inquilino", 300.00));
        departamentos.add(FabricaEntidades.crearDepartamento("D102", 102, 1, "Propietario", 350.00));
        departamentos.add(FabricaEntidades.crearDepartamento("D103", 103, 1, "Inquilino", 300.00));
        departamentos.add(FabricaEntidades.crearDepartamento("D201", 201, 2, "Propietario", 350.00));
        areas.add(FabricaEntidades.crearArea("A001", "Piscina", 3, 1, "Sin alimentos"));
        areas.add(FabricaEntidades.crearArea("A002", "Salón de eventos", 4, 2, "Hasta las 23:00"));
        areas.add(FabricaEntidades.crearArea("A003", "Parrilla", 2, 1, "Limpiar al terminar"));
        areas.add(FabricaEntidades.crearArea("A004", "Gimnasio", 1, 0, "Uso con toalla"));
        String[][] deudas = {
            {"P001", "D101", "Cuota mensual - octubre", "300.00", "Pendiente"},
            {"P002", "D101", "Servicio de agua", "85.50", "Pagado"},
            {"P003", "D102", "Cuota mensual - octubre", "350.00", "Pendiente"},
            {"P004", "D103", "Reparación de ascensor", "120.00", "Pagado"},
            {"P005", "D201", "Cuota mensual - octubre", "350.00", "Pendiente"} };
        for (String[] x : deudas) {
            Pago p = FabricaEntidades.crearDeuda(x[0], buscarDepartamento(x[1]), x[2], Double.parseDouble(x[3]));
            p.setEstado(x[4]);
            pagos.add(p);
        }
        reservas.add(FabricaEntidades.crearReserva("R001", "D101", "A001", "20/10/2026", "18:00", 3));
        reservas.add(FabricaEntidades.crearReserva("R002", "D102", "A002", "21/10/2026", "10:00", 4));
        mantenimientos.add(FabricaEntidades.crearMantenimiento("M001", "Departamento D101", "Fuga de agua en cocina", "Pendiente"));
        mantenimientos.add(FabricaEntidades.crearMantenimiento("M002", "Pasillo piso 2", "Foco quemado", "En proceso"));
    }

    public String getUsuarioActual() { return usuarioActual; }
    public void setUsuarioActual(String u) { usuarioActual = u; }

    /** Devuelve el departamento si el código y la clave coinciden; si no, null. */
    public Departamento autenticar(String codigo, String clave) {
        Departamento d = buscarDepartamento(codigo);
        return (d != null && d.getClave().equals(clave)) ? d : null;
    }

    public List<Pago> pagosDeDepartamento(String codigoDepartamento) {
        return pagos.stream().filter(p -> p.getDepartamento().equalsIgnoreCase(codigoDepartamento)).toList();
    }
    public double totalPagado(String codigoDepartamento) {
        return pagosDeDepartamento(codigoDepartamento).stream()
                .filter(p -> p.getEstado().equalsIgnoreCase("Pagado")).map(Pago::getMonto).reduce(0.0, Double::sum);
    }

    // Listas {código, descripción} para el autocompletado
    public List<String[]> sugerenciasDepartamentos() {
        return departamentos.stream().map(d -> new String[] { d.getCodigo(), "Depto " + d.getNumero() + " · " + d.getTipoOcupante() }).toList();
    }
    public List<String[]> sugerenciasAreas() {
        return areas.stream().map(a -> new String[] { a.getCodigo(), a.getNombre() + " · máx. " + a.getMaxHorasReserva() + " h" }).toList();
    }
    public List<String[]> sugerenciasPagos() {
        return pagos.stream().map(p -> new String[] { p.getCodigo(), p.getDepartamento() + " · " + p.getConcepto() + " · " + p.getEstado() }).toList();
    }
    public List<String[]> sugerenciasReservas() {
        return reservas.stream().map(r -> new String[] { r.getCodigo(), r.getDepartamento() + " · " + r.getArea() + " · " + r.getFecha() }).toList();
    }
    public List<String[]> sugerenciasMantenimientos() {
        return mantenimientos.stream().map(m -> new String[] { m.getCodigo(), m.getLugar() + " · " + m.getEstado() }).toList();
    }

    public static DatosCondominio getInstancia() {
        return INSTANCIA;
    }

    public ArrayList<Departamento> getDepartamentos() { return departamentos; }
    public ArrayList<Pago> getPagos() { return pagos; }
    public ArrayList<AreaComun> getAreas() { return areas; }
    public ArrayList<Reserva> getReservas() { return reservas; }
    public ArrayList<Mantenimiento> getMantenimientos() { return mantenimientos; }

    public Departamento buscarDepartamento(String codigo) {
        for (Departamento d : departamentos)
            if (d.getCodigo().equalsIgnoreCase(codigo)) return d;
        return null;
    }

    public Pago buscarPago(String codigo) {
        for (Pago p : pagos)
            if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        return null;
    }

    public AreaComun buscarArea(String codigo) {
        for (AreaComun a : areas)
            if (a.getCodigo().equalsIgnoreCase(codigo)) return a;
        return null;
    }

    public Reserva buscarReserva(String codigo) {
        for (Reserva r : reservas)
            if (r.getCodigo().equalsIgnoreCase(codigo)) return r;
        return null;
    }

    public Mantenimiento buscarMantenimiento(String codigo) {
        for (Mantenimiento m : mantenimientos)
            if (m.getCodigo().equalsIgnoreCase(codigo)) return m;
        return null;
    }

    // Programación funcional: filter + map + reduce sobre datos reales del sistema.
    public List<Pago> pagosPendientesPorDepartamento(String codigoDepartamento) {
        return pagos.stream()
                .filter(p -> p.getDepartamento().equalsIgnoreCase(codigoDepartamento))
                .filter(p -> p.getEstado().equalsIgnoreCase("Pendiente"))
                .toList();
    }

    public double totalPendiente(String codigoDepartamento) {
        return pagos.stream()
                .filter(p -> p.getDepartamento().equalsIgnoreCase(codigoDepartamento))
                .filter(p -> p.getEstado().equalsIgnoreCase("Pendiente"))
                .map(Pago::getMonto)
                .reduce(0.0, Double::sum);
    }
}
