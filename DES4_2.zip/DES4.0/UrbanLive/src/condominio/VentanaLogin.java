package condominio;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;

public class VentanaLogin extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel_1;
	private javax.swing.JTextField txtUsuario;
	private JLabel lblNewLabel_2;
	private JPasswordField txtContrasena;
	private JButton btnIngresar;
	private JLabel lblResultado;
	private JLabel lblNewLabel_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Estilos.aplicarTema();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaLogin frame = new VentanaLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaLogin() {
		setResizable(false);
		setTitle("LOGIN");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		{
			lblNewLabel_1 = new JLabel("Usuario:");
			lblNewLabel_1.setForeground(new Color(255, 255, 255));
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(28, 146, 71, 20);
			contentPane.add(lblNewLabel_1);
		}
		{
			txtUsuario = new javax.swing.JTextField();
			txtUsuario.setBounds(159, 144, 170, 24);
			contentPane.add(txtUsuario);
			AutoCompletar.instalar(txtUsuario, () -> {
				java.util.List<String[]> l = new java.util.ArrayList<String[]>();
				l.add(new String[] { "ADMIN", "Administrador" });
				l.addAll(DatosCondominio.getInstancia().sugerenciasDepartamentos());
				return l;
			});
		}
		{
			lblNewLabel_2 = new JLabel("Contraseña: ");
			lblNewLabel_2.setForeground(new Color(255, 255, 255));
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_2.setBounds(26, 173, 121, 20);
			contentPane.add(lblNewLabel_2);
		}
		{
			txtContrasena = new JPasswordField();
			txtContrasena.setBounds(159, 176, 170, 24);
			contentPane.add(txtContrasena);
		}
		{
			btnIngresar = new JButton("Ingresar");
			btnIngresar.addActionListener(this);
			btnIngresar.setBounds(159, 209, 170, 28);
			contentPane.add(btnIngresar);
			getRootPane().setDefaultButton(btnIngresar);
		}
		{
			lblResultado = new JLabel("");
			lblResultado.setForeground(new Color(255, 255, 255));
			lblResultado.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblResultado.setBounds(10, 274, 321, 38);
			contentPane.add(lblResultado);
		}
		{
			JButton btnInfo = new JButton("INFO");
			btnInfo.setBounds(159, 244, 80, 24);
			btnInfo.addActionListener(ev -> new VentanaInfo().setVisible(true));
			contentPane.add(btnInfo);
			JButton btnCreditos = new JButton("CRÉDITOS");
			btnCreditos.setBounds(245, 244, 90, 24);
			btnCreditos.addActionListener(ev -> { new VentanaCreditos().setVisible(true); new VentanaDesarrolladores().setVisible(true); });
			contentPane.add(btnCreditos);
			JButton btnCerrar = new JButton("CERRAR");
			btnCerrar.setBounds(341, 244, 80, 24);
			btnCerrar.addActionListener(ev -> {
				if (javax.swing.JOptionPane.showConfirmDialog(this, "¿Seguro que deseas salir?", "Cerrar", javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) System.exit(0);
			});
			contentPane.add(btnCerrar);
			lblNewLabel_3 = new JLabel("");
			lblNewLabel_3.setIcon(new ImageIcon(VentanaLogin.class.getResource("/imagenes/Urban_Live_JLabel_550x330.png")));
			lblNewLabel_3.setBounds(0, 0, 498, 325);
			contentPane.add(lblNewLabel_3);
		}

	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnIngresar) {
			do_btnIngresar_actionPerformed(e);
		}
	}
	protected void do_btnIngresar_actionPerformed(ActionEvent e) {
		String usuario = txtUsuario.getText().trim().toUpperCase();
		String clave = new String(txtContrasena.getPassword());
		DatosCondominio datos = DatosCondominio.getInstancia();
		if (usuario.isEmpty()) {
			lblResultado.setText("Ingresa tu usuario");
			return;
		}
		if (usuario.equals("ADMIN")) {
			if (clave.equals("123")) {
				datos.setUsuarioActual("ADMIN");
				new MenuPrincipal("Administrador", "ADMIN").setVisible(true);
				dispose();
			} else {
				lblResultado.setText("Contraseña incorrecta");
			}
			return;
		}
		Departamento d = datos.autenticar(usuario, clave);
		if (d != null) {
			datos.setUsuarioActual(d.getCodigo());
			new MenuPrincipal("Inquilino", d.getCodigo()).setVisible(true);
			dispose();
		} else {
			lblResultado.setText("Datos incorrectos");
		}
	}
}
