package condominio;

public class Reserva {
    private String codigo;
    private String departamento;
    private String area;
    private String fecha;
    private String hora;
    private int duracionHoras;

    public Reserva(String codigo, String departamento, String area, String fecha, String hora, int duracionHoras) {
        this.codigo = codigo;
        this.departamento = departamento;
        this.area = area;
        this.fecha = fecha;
        this.hora = hora;
        this.duracionHoras = duracionHoras;
    }

    public String getCodigo() { return codigo; }
    public String getDepartamento() { return departamento; }
    public String getArea() { return area; }
    public String getFecha() { return fecha; }
    public String getHora() { return hora; }
    public int getDuracionHoras() { return duracionHoras; }
}
