package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaDepartamentos extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtNumero;
    private JTextField txtPiso;
    private JTextField txtCuota;
    private JComboBox<String> comboTipo;
    private DefaultTableModel modelo;
    private javax.swing.JTextField txtClave;
    private JTable tabla;

    public VentanaDepartamentos() {
    	setModal(true);
        setTitle("Urban Live - Departamentos");
        setBounds(100, 100, 790, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Gestión de departamentos");
        titulo.setBounds(28, 18, 400, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Ejemplo: D001 · N.º 101 · Piso 1 · Inquilino · Cuota 300.00");
        ayuda.setBounds(30, 55, 700, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JLabel lblCodigo = new JLabel("Código");
        lblCodigo.setBounds(30, 90, 140, 20);
        contentPane.add(lblCodigo);

        txtCodigo = new JTextField();
        AutoCompletar.instalar(txtCodigo, () -> datos.sugerenciasDepartamentos());
        txtCodigo.setBounds(30, 113, 190, 30);
        txtCodigo.setToolTipText("Ej.: D001");
        contentPane.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblNumero = new JLabel("Número");
        lblNumero.setBounds(270, 90, 140, 20);
        contentPane.add(lblNumero);

        txtNumero = new JTextField();
        txtNumero.setBounds(270, 113, 190, 30);
        txtNumero.setToolTipText("Ej.: 101");
        contentPane.add(txtNumero);
        txtNumero.setColumns(10);

        JLabel lblPiso = new JLabel("Piso");
        lblPiso.setBounds(510, 90, 140, 20);
        contentPane.add(lblPiso);

        txtPiso = new JTextField();
        txtPiso.setBounds(510, 113, 190, 30);
        txtPiso.setToolTipText("Ej.: 1");
        contentPane.add(txtPiso);
        txtPiso.setColumns(10);

        JLabel lblTipo = new JLabel("Ocupación");
        lblTipo.setBounds(30, 155, 120, 20);
        contentPane.add(lblTipo);

        comboTipo = new JComboBox<String>(new String[] {"Propietario", "Inquilino"});
        comboTipo.setBounds(30, 178, 190, 30);
        contentPane.add(comboTipo);

        JLabel lblCuota = new JLabel("Cuota mensual");
        lblCuota.setBounds(270, 155, 140, 20);
        contentPane.add(lblCuota);

        txtCuota = new JTextField();
        txtCuota.setBounds(270, 178, 190, 30);
        txtCuota.setToolTipText("Ej.: 300.00");
        contentPane.add(txtCuota);
        txtCuota.setColumns(10);

        JLabel lblClave = new JLabel("Contraseña inicial (vacío = el código)");
        lblClave.setBounds(30, 220, 330, 20);
        contentPane.add(lblClave);
        txtClave = new JTextField();
        txtClave.setBounds(30, 243, 190, 30);
        txtClave.setToolTipText("El residente podrá cambiarla al ingresar");
        contentPane.add(txtClave);
        JButton btnRegistrar = new JButton("REGISTRAR");
        btnRegistrar.setBounds(510, 155, 110, 32);
        btnRegistrar.setToolTipText("Guarda un departamento nuevo");
        Estilos.boton(btnRegistrar);
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrar();
            }
        });
        contentPane.add(btnRegistrar);

        JButton btnBuscar = new JButton("BUSCAR");
        btnBuscar.setBounds(630, 155, 110, 32);
        btnBuscar.setToolTipText("Busca por código");
        Estilos.boton(btnBuscar);
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscar();
            }
        });
        contentPane.add(btnBuscar);

        JButton btnActualizar = new JButton("ACTUALIZAR");
        btnActualizar.setBounds(510, 195, 110, 32);
        btnActualizar.setToolTipText("Guarda los cambios");
        Estilos.boton(btnActualizar);
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizar();
            }
        });
        contentPane.add(btnActualizar);

        JButton btnLimpiar = new JButton("LIMPIAR");
        btnLimpiar.setBounds(630, 195, 110, 32);
        btnLimpiar.setToolTipText("Vacía los campos");
        Estilos.boton(btnLimpiar);
        btnLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        });
        contentPane.add(btnLimpiar);

        modelo = new DefaultTableModel(new Object[] {"Código", "Número", "Piso", "Ocupación", "Cuota", "Contraseña"}, 0);
        tabla = new JTable(modelo);
        Estilos.colorearEstado(tabla, 5);
        tabla.setToolTipText("Haz clic en una fila para cargar sus datos");
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                    cargarFila();
                }
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 295, 710, 190);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("REGRESAR");
        btnVolver.setBounds(630, 495, 110, 32);
        btnVolver.setToolTipText("Regresa al menú principal");
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);

        actualizarTabla();
    }

    private void registrar() {
        try {
            String codigo = txtCodigo.getText().trim().toUpperCase();
            if (codigo.isEmpty() || datos.buscarDepartamento(codigo) != null) {
                JOptionPane.showMessageDialog(this, "Usa un código nuevo. Ejemplo: D001");
                return;
            }

            Departamento d = new Departamento(
                    codigo,
                    Integer.parseInt(txtNumero.getText().trim()),
                    Integer.parseInt(txtPiso.getText().trim()),
                    comboTipo.getSelectedItem().toString(),
                    Double.parseDouble(txtCuota.getText().trim()));

            if (!txtClave.getText().trim().isEmpty()) {
                d.restablecerClave(txtClave.getText().trim());
            }
            datos.getDepartamentos().add(d);
            actualizarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Departamento registrado correctamente.\nUsuario: " + codigo + "   |   Contraseña inicial: " + d.getClave());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Número y piso deben ser enteros; la cuota debe ser numérica.");
        }
    }

    private void buscar() {
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) {
            JOptionPane.showMessageDialog(this, "Departamento no encontrado.");
            return;
        }
        cargarDepartamento(d);
    }

    private void actualizar() {
        Departamento d = datos.buscarDepartamento(txtCodigo.getText().trim());
        if (d == null) {
            JOptionPane.showMessageDialog(this, "Busca o selecciona un departamento.");
            return;
        }
        try {
            d.setNumero(Integer.parseInt(txtNumero.getText().trim()));
            d.setPiso(Integer.parseInt(txtPiso.getText().trim()));
            d.setTipoOcupante(comboTipo.getSelectedItem().toString());
            d.setCuota(Double.parseDouble(txtCuota.getText().trim()));
            if (!txtClave.getText().trim().isEmpty()) {
                d.restablecerClave(txtClave.getText().trim());
            }
            actualizarTabla();
            JOptionPane.showMessageDialog(this, "Departamento actualizado.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Revisa número, piso y cuota.");
        }
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        Departamento d = datos.buscarDepartamento(modelo.getValueAt(fila, 0).toString());
        if (d != null) {
            cargarDepartamento(d);
        }
    }

    private void cargarDepartamento(Departamento d) {
        txtCodigo.setText(d.getCodigo());
        txtNumero.setText(String.valueOf(d.getNumero()));
        txtPiso.setText(String.valueOf(d.getPiso()));
        comboTipo.setSelectedItem(d.getTipoOcupante());
        txtCuota.setText(String.valueOf(d.getCuota()));
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Departamento d : datos.getDepartamentos()) {
            modelo.addRow(new Object[] {d.getCodigo(), d.getNumero(), d.getPiso(), d.getTipoOcupante(), d.getCuota(), d.isClaveCambiada() ? "Cambiada" : "Inicial"});
        }
    }

    private void limpiar() {
        txtCodigo.setText("");
        txtNumero.setText("");
        txtPiso.setText("");
        txtCuota.setText("");
        txtClave.setText("");
        comboTipo.setSelectedIndex(0);
        tabla.clearSelection();
    }
}
