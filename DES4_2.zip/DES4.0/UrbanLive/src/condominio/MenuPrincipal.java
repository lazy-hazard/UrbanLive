package condominio;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class MenuPrincipal extends JFrame implements ActionListener, MouseListener {
    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JButton btnDepartamentos;
    private JButton btnPagos;
    private JButton btnAreas;
    private JButton btnReservas;
    private JButton btnMantenimiento;
    private JButton btnSalir;
    private JButton btnCreditos;
    private JLabel lblNewLabel;
    private String rol;
    private String usuario = "";
    private JLabel lblAdministracinSimplePara;

    public static void main(String[] args) {
        
    }

    public MenuPrincipal(String rol) {
        this(rol, "");
    }

    public MenuPrincipal(String rol, String usuario) {
        this.rol = rol;
        this.usuario = usuario;
        setTitle("Urban Live");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setBounds(100, 100, 810, 613);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(24, 34, 24, 34));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitulo = new JLabel("URBAN LIVE");
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(456, 54, 297, 38);
        Estilos.titulogrande(lblTitulo);
        contentPane.add(lblTitulo);

        JLabel lblSubtitulo = new JLabel("Administración simple para tu condominio");
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setBounds(438, 117, 329, 24);
        Estilos.subtitulomenu(lblSubtitulo);
        contentPane.add(lblSubtitulo);

        btnDepartamentos = new JButton("DEPARTAMENTOS");
        btnDepartamentos.addMouseListener(this);
        btnDepartamentos.setBounds(36, 47, 235, 52);
        btnDepartamentos.setToolTipText("Registra y consulta departamentos");
        Estilos.botonazul(btnDepartamentos);
        btnDepartamentos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	new VentanaDepartamentos().setVisible(true);
            }
        });
        contentPane.add(btnDepartamentos);

        btnPagos = new JButton("PAGOS Y DEUDAS");
        btnPagos.setBounds(36, 257, 235, 52);
        btnPagos.setToolTipText("Consultar/pagar o administrar deudas");
        Estilos.botonazul(btnPagos);
        btnPagos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (MenuPrincipal.this.rol.equals("Administrador")) {
                    new VentanaAdministrarPagos().setVisible(true);
                } else {
                    new VentanaConsultaPagos(MenuPrincipal.this.usuario).setVisible(true);
                }
            }
        });
        contentPane.add(btnPagos);

        btnAreas = new JButton("ÁREAS COMUNES");
        btnAreas.setBounds(36, 117, 235, 52);
        btnAreas.setToolTipText("Registra y consulta áreas comunes");
        Estilos.botonazul(btnAreas);
        btnAreas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	new VentanaAreasComunes().setVisible(true);
            }
        });
        contentPane.add(btnAreas);

        btnReservas = new JButton("RESERVAS");
        btnReservas.setBounds(36, 327, 235, 52);
        btnReservas.setToolTipText("Reservar áreas según sus reglas de uso");
        Estilos.botonazul(btnReservas);
        btnReservas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaReservas(MenuPrincipal.this.rol, MenuPrincipal.this.usuario).setVisible(true);
            }
        });
        contentPane.add(btnReservas);

        btnMantenimiento = new JButton("MANTENIMIENTO");
        btnMantenimiento.setBounds(36, 187, 235, 52);
        btnMantenimiento.setToolTipText("Registra zonas que requieran mantenimiento");
        Estilos.botonazul(btnMantenimiento);
        btnMantenimiento.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	new VentanaMantenimiento().setVisible(true);
            }
        });
        contentPane.add(btnMantenimiento);

        btnSalir = new JButton("SALIR");
        btnSalir.setBounds(36, 467, 235, 45);
        Estilos.botonazul(btnSalir);
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaLogin().setVisible(true);
                dispose();
            }
        });
        contentPane.add(btnSalir);
        
        btnCreditos = new JButton("CREDITOS");
        btnCreditos.addActionListener(this);
        btnCreditos.setToolTipText("Creadores del proyecto");
        btnCreditos.setBounds(36, 397, 235, 52);
        Estilos.botonazul(btnCreditos);
        contentPane.add(btnCreditos);
        
        lblAdministracinSimplePara = new JLabel("Administración simple para tu sxdcondominio");
        lblAdministracinSimplePara.setIcon(new ImageIcon(MenuPrincipal.class.getResource("/imagenes/b842316b-b14f-40df-819d-b704c479ef23.png")));
        lblAdministracinSimplePara.setHorizontalAlignment(SwingConstants.CENTER);
        lblAdministracinSimplePara.setBounds(475, 257, 255, 255);
        contentPane.add(lblAdministracinSimplePara);
        
        JButton btnClave = new JButton("CAMBIAR CONTRASEÑA");
        btnClave.setToolTipText("Cambia tu clave de acceso");
        Estilos.botonazul(btnClave);
        btnClave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaCambiarClave(MenuPrincipal.this.usuario).setVisible(true);
            }
        });
        contentPane.add(btnClave);
        JButton btnInfo = new JButton("INFO");
        btnInfo.setToolTipText("Acerca de Urban Live y créditos");
        Estilos.botonazul(btnInfo);
        btnInfo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaInfo().setVisible(true);
            }
        });
        contentPane.add(btnInfo);
        lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(MenuPrincipal.class.getResource("/imagenes/fondo.jpg")));
        lblNewLabel.setBounds(0, 0, 794, 574);
        contentPane.add(lblNewLabel);
        
        
     // Permisos según el tipo de usuario
        boolean admin = rol.equals("Administrador");
        JButton[] todos = { btnDepartamentos, btnAreas, btnMantenimiento, btnPagos, btnReservas, btnCreditos, btnClave, btnInfo, btnSalir };
        for (JButton b : todos) b.setVisible(false);
        btnPagos.setText(admin ? "DEUDAS" : "PAGOS");
        JButton[] orden = admin
            ? new JButton[] { btnDepartamentos, btnAreas, btnMantenimiento, btnPagos, btnReservas, btnInfo, btnSalir }
            : new JButton[] { btnPagos, btnReservas, btnClave, btnInfo, btnSalir };
        for (int i = 0; i < orden.length; i++) {
            orden[i].setBounds(36, 40 + i * 68, 235, 50);
            orden[i].setVisible(true);
        }
        lblSubtitulo.setText(admin ? "Panel del administrador" : "Bienvenido, departamento " + usuario);
        
    
    }
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnCreditos) {
			do_btnCreditos_actionPerformed(e);
		}
	}
	protected void do_btnCreditos_actionPerformed(ActionEvent e) {
		new VentanaCreditos().setVisible(true);
		new VentanaDesarrolladores().setVisible(true);
		
	}
	public void mouseClicked(MouseEvent e) {
	}
	public void mouseEntered(MouseEvent e) {
		
	}
	public void mouseExited(MouseEvent e) {
	}
	public void mousePressed(MouseEvent e) {
	}
	public void mouseReleased(MouseEvent e) {
	}
	
}
