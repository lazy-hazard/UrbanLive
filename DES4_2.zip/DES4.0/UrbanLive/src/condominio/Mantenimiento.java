package condominio;

public class Mantenimiento {
    private String codigo;
    private String lugar;
    private String descripcion;
    private String estado;

    public Mantenimiento(String codigo, String lugar, String descripcion, String estado) {
        this.codigo = codigo;
        this.lugar = lugar;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public String getCodigo() { return codigo; }
    public String getLugar() { return lugar; }
    public String getDescripcion() { return descripcion; }
    public String getEstado() { return estado; }

    public void setLugar(String lugar) { this.lugar = lugar; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setEstado(String estado) { this.estado = estado; }
}
