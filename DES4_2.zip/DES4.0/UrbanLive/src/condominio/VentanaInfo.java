package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class VentanaInfo extends JDialog {
    private static final long serialVersionUID = 1L;

    public VentanaInfo() {
        setModal(true);
        setTitle("Urban Live - Información");
        setBounds(100, 100, 560, 470);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        JPanel p = new JPanel();
        p.setBackground(Estilos.FONDO);
        p.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(p);
        p.setLayout(null);

        JLabel titulo = new JLabel("Acerca de Urban Live");
        titulo.setBounds(28, 18, 460, 35);
        Estilos.titulo(titulo);
        p.add(titulo);

        JTextArea txt = new JTextArea(
            "Urban Live nace de la necesidad de facilitar el manejo de grandes y pequeños "
          + "condominios, ofreciendo una conectividad exclusiva entre administrador y usuario.\n\n"
          + "Desde un solo lugar, el residente consulta y paga sus deudas, reserva áreas comunes "
          + "con reglas claras y cambia su contraseña, mientras el administrador gestiona "
          + "departamentos, áreas, pagos, reservas y mantenimiento.\n\n"
          + "Simple, transparente y siempre a mano.");
        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setOpaque(false);
        txt.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 15));
        txt.setForeground(Estilos.TEXTO);
        txt.setBounds(30, 75, 490, 270);
        p.add(txt);

        JButton creditos = new JButton("CRÉDITOS");
        creditos.setBounds(30, 370, 140, 36);
        Estilos.boton(creditos);
        creditos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new VentanaCreditos().setVisible(true);
                new VentanaDesarrolladores().setVisible(true);
            }
        });
        p.add(creditos);
        JButton cerrar = new JButton("CERRAR");
        cerrar.setBounds(380, 370, 140, 36);
        Estilos.botonazul(cerrar);
        cerrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { dispose(); }
        });
        p.add(cerrar);
    }
}
