package condominio;

public final class FabricaEntidades {
    private FabricaEntidades() { }

    public static Departamento crearDepartamento(String codigo, int numero, int piso, String tipoOcupante, double cuota) {
        return new Departamento(codigo, numero, piso, tipoOcupante, cuota);
    }

    public static Pago crearDeuda(String codigo, Departamento departamento, String concepto, double monto) {
        return new Pago(codigo, departamento.getCodigo(), departamento.getTipoOcupante(), concepto, monto, "Pendiente");
    }

    public static AreaComun crearArea(String codigo, String nombre, int maxHoras, int separacion, String reglas) {
        return new AreaComun(codigo, nombre, maxHoras, separacion, reglas);
    }

    public static Reserva crearReserva(String codigo, String departamento, String area, String fecha, String hora, int duracion) {
        return new Reserva(codigo, departamento, area, fecha, hora, duracion);
    }

    public static Mantenimiento crearMantenimiento(String codigo, String lugar, String descripcion, String estado) {
        return new Mantenimiento(codigo, lugar, descripcion, estado);
    }
}
