package condominio;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Estilos {
	public static final Color AMARILLO = new Color(166, 130, 64);
    public static final Color VERDE = new Color(31, 58, 95);
    public static final Color VERDE_OSCURO = new Color(31, 58, 95);
    public static final Color FONDO = new Color(244, 240, 234);
    public static final Color TEXTO = new Color(31, 41, 55);
    public static final Color BLANCO = Color.WHITE;
    public static final Color BLACK = Color.BLACK;
    public static final Color BLUES = new Color(44, 79, 124);

    private Estilos() { }

    /** Tema sobrio: azul marino, beige y dorado. Llamar una vez al iniciar. */
    public static void aplicarTema() {
        javax.swing.UIManager.put("Panel.background", FONDO);
        javax.swing.UIManager.put("OptionPane.background", FONDO);
        javax.swing.UIManager.put("OptionPane.messageForeground", TEXTO);
        javax.swing.UIManager.put("TableHeader.background", BLUES);
        javax.swing.UIManager.put("TableHeader.foreground", BLANCO);
        javax.swing.UIManager.put("Table.selectionBackground", new Color(233, 225, 211));
        javax.swing.UIManager.put("Table.selectionForeground", TEXTO);
        javax.swing.UIManager.put("Table.gridColor", new Color(214, 205, 189));
    }

    /** Colorea la columna de estado: Pendiente/En proceso en rojo-ámbar, Pagado/Vigente/Terminado en verde. */
    public static void colorearEstado(javax.swing.JTable tabla, int columna) {
        tabla.getColumnModel().getColumn(columna).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            public java.awt.Component getTableCellRendererComponent(javax.swing.JTable t, Object v,
                    boolean sel, boolean foco, int fila, int col) {
                java.awt.Component c = super.getTableCellRendererComponent(t, v, sel, foco, fila, col);
                String s = String.valueOf(v);
                c.setFont(c.getFont().deriveFont(Font.BOLD));
                if (s.equals("Pendiente")) c.setForeground(new Color(181, 74, 74));
                else if (s.equals("En proceso") || s.equals("Inicial")) c.setForeground(new Color(184, 120, 0));
                else if (s.equals("Pagado") || s.equals("Vigente") || s.equals("Terminado") || s.equals("Cambiada")) c.setForeground(new Color(46, 125, 91));
                else c.setForeground(new Color(107, 114, 128));
                return c;
            }
        });
    }
    public static void titulogrande(JLabel label) {
    	label.setFont(new Font("SansSerif", Font.BOLD, 32));
    	label.setForeground(BLANCO);
    }

    public static void titulo(JLabel label) {
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        label.setForeground(VERDE_OSCURO);
    }
    public static void titulomenu(JLabel label) {
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        label.setForeground(BLANCO);
    }
    public static void botonazul(JButton boton) {
        boton.setBackground(BLUES);
        boton.setForeground(BLANCO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
    }
    
    public static void subtitulo(JLabel label) {
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        label.setForeground(new Color(90, 100, 96));
    }
    public static void subtitulomenu(JLabel label) {
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        label.setForeground(BLANCO);
    }

    public static void boton(JButton boton) {
        boton.setBackground(AMARILLO);
        boton.setForeground(BLANCO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
    }

    public static JPanel panel() {
        JPanel p = new JPanel();
        p.setBackground(FONDO);
        p.setBorder(new EmptyBorder(18, 18, 18, 18));
        return p;
    }

    public static void fondo(JComponent componente) {
        componente.setBackground(FONDO);
    }
}
