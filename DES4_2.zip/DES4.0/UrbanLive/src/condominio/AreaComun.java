package condominio;

public class AreaComun {
    private String codigo;
    private String nombre;
    private int maxHorasReserva;
    private int horasEntreReservas;
    private String reglas;

    public AreaComun(String codigo, String nombre, int maxHorasReserva, int horasEntreReservas, String reglas) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.maxHorasReserva = maxHorasReserva;
        this.horasEntreReservas = horasEntreReservas;
        this.reglas = reglas;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public int getMaxHorasReserva() { return maxHorasReserva; }
    public int getHorasEntreReservas() { return horasEntreReservas; }
    public String getReglas() { return reglas; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setMaxHorasReserva(int maxHorasReserva) { this.maxHorasReserva = maxHorasReserva; }
    public void setHorasEntreReservas(int horasEntreReservas) { this.horasEntreReservas = horasEntreReservas; }
    public void setReglas(String reglas) { this.reglas = reglas; }
}
