package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

public class VentanaCambiarClave extends JDialog {
    private static final long serialVersionUID = 1L;
    private final String codigo;
    private final JPasswordField txtActual = new JPasswordField();
    private final JPasswordField txtNueva = new JPasswordField();
    private final JPasswordField txtConfirmar = new JPasswordField();

    public VentanaCambiarClave(String codigoDepartamento) {
        this.codigo = codigoDepartamento;
        setModal(true);
        setTitle("Urban Live - Cambiar contraseña");
        setBounds(100, 100, 460, 440);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        JPanel p = new JPanel();
        p.setBackground(Estilos.FONDO);
        p.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(p);
        p.setLayout(null);

        JLabel titulo = new JLabel("Cambiar contraseña");
        titulo.setBounds(28, 18, 380, 35);
        Estilos.titulo(titulo);
        p.add(titulo);
        JLabel ayuda = new JLabel("Departamento " + codigo + " · usa una clave que solo tú conozcas");
        ayuda.setBounds(30, 55, 400, 22);
        Estilos.subtitulo(ayuda);
        p.add(ayuda);

        campo(p, "Contraseña actual", txtActual, 95);
        campo(p, "Nueva contraseña (mínimo 4 caracteres)", txtNueva, 165);
        campo(p, "Confirmar nueva contraseña", txtConfirmar, 235);

        JButton guardar = new JButton("GUARDAR");
        guardar.setBounds(30, 320, 140, 36);
        Estilos.boton(guardar);
        guardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { guardar(); }
        });
        p.add(guardar);
        JButton cancelar = new JButton("CANCELAR");
        cancelar.setBounds(185, 320, 140, 36);
        Estilos.botonazul(cancelar);
        cancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtActual.setText("");
                txtNueva.setText("");
                txtConfirmar.setText("");
            }
        });
        p.add(cancelar);
        JButton regresar = new JButton("REGRESAR");
        regresar.setBounds(300, 365, 120, 30);
        Estilos.botonazul(regresar);
        regresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { dispose(); }
        });
        p.add(regresar);
        getRootPane().setDefaultButton(guardar);
    }

    private void campo(JPanel p, String texto, JPasswordField f, int y) {
        JLabel l = new JLabel(texto);
        l.setBounds(30, y, 380, 20);
        p.add(l);
        f.setBounds(30, y + 23, 380, 30);
        p.add(f);
    }

    private void guardar() {
        Departamento d = DatosCondominio.getInstancia().buscarDepartamento(codigo);
        if (d == null) {
            JOptionPane.showMessageDialog(this, "Esta opción es solo para residentes.");
            return;
        }
        String actual = new String(txtActual.getPassword());
        String nueva = new String(txtNueva.getPassword());
        String conf = new String(txtConfirmar.getPassword());
        if (!d.getClave().equals(actual)) {
            JOptionPane.showMessageDialog(this, "La contraseña actual es incorrecta.");
            return;
        }
        if (nueva.length() < 4) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña debe tener al menos 4 caracteres.");
            return;
        }
        if (!nueva.equals(conf)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.");
            return;
        }
        if (nueva.equals(actual)) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña debe ser distinta a la actual.");
            return;
        }
        d.cambiarClave(nueva);
        JOptionPane.showMessageDialog(this, "Contraseña cambiada correctamente.");
        dispose();
    }
}
