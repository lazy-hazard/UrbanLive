package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VentanaAdministrarPagos extends JDialog {
    private static final long serialVersionUID = 1L;

    private final DatosCondominio datos = DatosCondominio.getInstancia();
    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtDepartamento;
    private JTextField txtMonto;
    private JTextField txtConcepto;
    private DefaultTableModel modelo;
    private JTable tabla;

    public VentanaAdministrarPagos() {
    	setModal(true);
        setTitle("Urban Live - Administrar pagos");
        setBounds(100, 100, 820, 590);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBackground(Estilos.FONDO);
        contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titulo = new JLabel("Herramientas de administrador - Pagos");
        titulo.setBounds(28, 18, 500, 35);
        Estilos.titulo(titulo);
        contentPane.add(titulo);

        JLabel ayuda = new JLabel("Ejemplo: P001 · D001 · Inquilino · Cuota mensual · S/ 300.00 · Pendiente");
        ayuda.setBounds(30, 55, 730, 22);
        Estilos.subtitulo(ayuda);
        contentPane.add(ayuda);

        JLabel lblCodigo = new JLabel("Código de deuda");
        lblCodigo.setBounds(30, 90, 180, 20);
        contentPane.add(lblCodigo);

        txtCodigo = new JTextField();
        AutoCompletar.instalar(txtCodigo, () -> datos.sugerenciasPagos());
        txtCodigo.setBounds(30, 113, 190, 30);
        txtCodigo.setToolTipText("Ej.: P001");
        contentPane.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblDepartamento = new JLabel("Departamento");
        lblDepartamento.setBounds(270, 90, 180, 20);
        contentPane.add(lblDepartamento);

        txtDepartamento = new JTextField();
        AutoCompletar.instalar(txtDepartamento, () -> datos.sugerenciasDepartamentos());
        txtDepartamento.setBounds(270, 113, 190, 30);
        txtDepartamento.setToolTipText("Ej.: D001");
        contentPane.add(txtDepartamento);
        txtDepartamento.setColumns(10);

        JLabel lblConcepto = new JLabel("Concepto");
        lblConcepto.setBounds(510, 90, 180, 20);
        contentPane.add(lblConcepto);

        txtConcepto = new JTextField();
        txtConcepto.setBounds(510, 113, 190, 30);
        txtConcepto.setToolTipText("Ej.: Cuota mensual");
        contentPane.add(txtConcepto);
        txtConcepto.setColumns(10);

        JLabel lblMonto = new JLabel("Monto");
        lblMonto.setBounds(30, 155, 180, 20);
        contentPane.add(lblMonto);

        txtMonto = new JTextField();
        txtMonto.setBounds(30, 178, 190, 30);
        txtMonto.setToolTipText("Ej.: 300.00");
        contentPane.add(txtMonto);
        txtMonto.setColumns(10);

        JButton btnRegistrar = new JButton("REGISTRAR DEUDA");
        btnRegistrar.setBounds(270, 178, 145, 32);
        Estilos.boton(btnRegistrar);
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrar();
            }
        });
        contentPane.add(btnRegistrar);

        JButton btnEliminar = new JButton("ELIMINAR DEUDA");
        btnEliminar.setBounds(425, 178, 145, 32);
        Estilos.boton(btnEliminar);
        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminar();
            }
        });
        contentPane.add(btnEliminar);

        JButton btnLimpiar = new JButton("LIMPIAR");
        btnLimpiar.setBounds(580, 178, 120, 32);
        Estilos.boton(btnLimpiar);
        btnLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        });
        contentPane.add(btnLimpiar);

        modelo = new DefaultTableModel(new Object[] {"Código", "Departamento", "Tipo", "Concepto", "Monto", "Estado"}, 0);
        tabla = new JTable(modelo);
        Estilos.colorearEstado(tabla, 5);
        tabla.setToolTipText("Selecciona una deuda para cargar sus datos");
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                    cargarFila();
                }
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(30, 240, 730, 220);
        contentPane.add(scroll);

        JButton btnVolver = new JButton("REGRESAR");
        btnVolver.setBounds(640, 485, 120, 32);
        Estilos.boton(btnVolver);
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnVolver);

        actualizarTabla();
    }

    private void registrar() {
        String codigo = txtCodigo.getText().trim().toUpperCase();
        String dep = txtDepartamento.getText().trim().toUpperCase();
        String concepto = txtConcepto.getText().trim();
        Departamento d = datos.buscarDepartamento(dep);

        if (codigo.isEmpty() || concepto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos.");
            return;
        }
        if (datos.buscarPago(codigo) != null) {
            JOptionPane.showMessageDialog(this, "El código de deuda ya existe.");
            return;
        }
        if (d == null) {
            JOptionPane.showMessageDialog(this, "El departamento no existe.");
            return;
        }

        try {
            double monto = Double.parseDouble(txtMonto.getText().trim());
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "El monto debe ser mayor que 0.");
                return;
            }
            Pago p = FabricaEntidades.crearDeuda(codigo, d, concepto, monto);
            datos.getPagos().add(p);
            actualizarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Deuda registrada.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El monto debe ser numérico. Ejemplo: 300.00");
        }
    }

    private void eliminar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona una deuda de la tabla.");
            return;
        }
        Pago p = datos.buscarPago(modelo.getValueAt(fila, 0).toString());
        if (p == null) {
            return;
        }

        int op = JOptionPane.showConfirmDialog(this, "¿Eliminar la deuda " + p.getCodigo() + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            datos.getPagos().remove(p);
            actualizarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Deuda eliminada.");
        }
    }

    private void cargarFila() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        txtCodigo.setText(modelo.getValueAt(fila, 0).toString());
        txtDepartamento.setText(modelo.getValueAt(fila, 1).toString());
        txtConcepto.setText(modelo.getValueAt(fila, 3).toString());
        txtMonto.setText(modelo.getValueAt(fila, 4).toString());
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Pago p : datos.getPagos()) {
            modelo.addRow(new Object[] {p.getCodigo(), p.getDepartamento(), p.getTipoOcupante(), p.getConcepto(), p.getMonto(), p.getEstado()});
        }
    }

    private void limpiar() {
        txtCodigo.setText("");
        txtDepartamento.setText("");
        txtConcepto.setText("");
        txtMonto.setText("");
        tabla.clearSelection();
    }
}
