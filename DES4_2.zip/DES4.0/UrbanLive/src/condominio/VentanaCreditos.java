package condominio;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

import java.awt.Dialog.ModalExclusionType;

public class VentanaCreditos extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaCreditos frame = new VentanaCreditos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaCreditos() {
		setModal(true);
		setResizable(false);
		setTitle("UrbanLive - Creditos");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 838, 697);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		{
			lblNewLabel = new JLabel("");
			lblNewLabel.setIcon(new ImageIcon(VentanaCreditos.class.getResource("/imagenes/1.jpeg")));
			lblNewLabel.setBounds(21, 20, 195, 227);
			contentPane.add(lblNewLabel);
		}
		{
			lblNewLabel_1 = new JLabel("");
			lblNewLabel_1.setIcon(new ImageIcon(VentanaCreditos.class.getResource("/imagenes/4.jpeg")));
			lblNewLabel_1.setBounds(298, 20, 195, 227);
			contentPane.add(lblNewLabel_1);
		}
		{
			lblNewLabel_2 = new JLabel("");
			lblNewLabel_2.setIcon(new ImageIcon(VentanaCreditos.class.getResource("/imagenes/2.jpeg")));
			lblNewLabel_2.setBounds(21, 327, 195, 227);
			contentPane.add(lblNewLabel_2);
		}
		{
			lblNewLabel_3 = new JLabel("");
			lblNewLabel_3.setIcon(new ImageIcon(VentanaCreditos.class.getResource("/imagenes/5.jpg")));
			lblNewLabel_3.setBounds(584, 20, 163, 227);
			contentPane.add(lblNewLabel_3);
		}
		{
			lblNewLabel_4 = new JLabel("");
			lblNewLabel_4.setIcon(new ImageIcon(VentanaCreditos.class.getResource("/imagenes/3.jpeg")));
			lblNewLabel_4.setBounds(298, 327, 195, 227);
			contentPane.add(lblNewLabel_4);
		}
		{
			lblNewLabel_5 = new JLabel("Gianpiero Tovar Díaz - N00547739");
			lblNewLabel_5.setBounds(21, 268, 244, 34);
			contentPane.add(lblNewLabel_5);
		}
		{
			lblNewLabel_6 = new JLabel("Adriano Tomasto Fabian - N00539492");
			lblNewLabel_6.setBounds(21, 579, 244, 34);
			contentPane.add(lblNewLabel_6);
		}
		{
			lblNewLabel_7 = new JLabel("Alvaro Leon Astulla - N00549719");
			lblNewLabel_7.setBounds(298, 579, 254, 34);
			contentPane.add(lblNewLabel_7);
		}
		{
			lblNewLabel_8 = new JLabel("Neomar Alfredo Guillent Yepez - N00523494");
			lblNewLabel_8.setBounds(274, 268, 278, 34);
			contentPane.add(lblNewLabel_8);
		}
		{
			lblNewLabel_9 = new JLabel("Joaquín Mendoza Garibay - N00531650");
			lblNewLabel_9.setBounds(562, 268, 252, 34);
			contentPane.add(lblNewLabel_9);
		}

	}
}
