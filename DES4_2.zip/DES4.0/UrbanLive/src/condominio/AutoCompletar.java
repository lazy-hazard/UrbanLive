package condominio;

import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.function.Supplier;

import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Muestra códigos disponibles que empiezan con lo escrito (ej. "D1" -> D101, D102...). */
public final class AutoCompletar {

    private AutoCompletar() { }

    /** fuente devuelve pares {codigo, descripcion}. */
    public static void instalar(final JTextField campo, final Supplier<List<String[]>> fuente) {
        final JPopupMenu popup = new JPopupMenu();
        popup.setFocusable(false);
        final DefaultListModel<String> modelo = new DefaultListModel<String>();
        final JList<String> lista = new JList<String>(modelo);
        lista.setFocusable(false);
        lista.setBackground(Estilos.BLANCO);
        lista.setSelectionBackground(new java.awt.Color(233, 225, 211));
        lista.setSelectionForeground(Estilos.TEXTO);
        popup.add(lista);
        final boolean[] interno = { false };

        final Runnable elegir = new Runnable() {
            public void run() {
                String v = lista.getSelectedValue();
                if (v == null) return;
                interno[0] = true;
                campo.setText(v.split(" ")[0]);
                interno[0] = false;
                popup.setVisible(false);
                campo.requestFocusInWindow();
            }
        };

        final Runnable actualizar = new Runnable() {
            public void run() {
                String t = campo.getText().trim().toUpperCase();
                modelo.clear();
                if (!t.isEmpty() && campo.isEditable() && campo.isShowing() && campo.hasFocus()) {
                    int n = 0;
                    for (String[] it : fuente.get()) {
                        if (it[0].toUpperCase().startsWith(t)) {
                            modelo.addElement(it[0] + "   ·   " + it[1]);
                            if (++n >= 8) break;
                        }
                    }
                }
                if (modelo.isEmpty()) {
                    popup.setVisible(false);
                    return;
                }
                lista.setSelectedIndex(0);
                lista.setVisibleRowCount(modelo.size());
                popup.setPopupSize(Math.max(campo.getWidth(), 260), modelo.size() * 20 + 6);
                if (!popup.isVisible()) popup.show(campo, 0, campo.getHeight());
                campo.requestFocusInWindow();
            }
        };

        campo.getDocument().addDocumentListener(new DocumentListener() {
            private void cambio() {
                if (!interno[0]) SwingUtilities.invokeLater(actualizar);
            }
            public void insertUpdate(DocumentEvent e) { cambio(); }
            public void removeUpdate(DocumentEvent e) { cambio(); }
            public void changedUpdate(DocumentEvent e) { cambio(); }
        });

        lista.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = lista.locationToIndex(e.getPoint());
                if (i >= 0) {
                    lista.setSelectedIndex(i);
                    elegir.run();
                }
            }
        });

        campo.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { popup.setVisible(false); }
        });

        final javax.swing.Action original = campo.getActionMap().get("notify-field-accept");
        campo.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "ac-enter");
        campo.getActionMap().put("ac-enter", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if (popup.isVisible()) elegir.run();
                else if (original != null) original.actionPerformed(e);
            }
        });
        campo.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "ac-down");
        campo.getActionMap().put("ac-down", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if (popup.isVisible() && lista.getSelectedIndex() < modelo.size() - 1)
                    lista.setSelectedIndex(lista.getSelectedIndex() + 1);
            }
        });
        campo.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "ac-up");
        campo.getActionMap().put("ac-up", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if (popup.isVisible() && lista.getSelectedIndex() > 0)
                    lista.setSelectedIndex(lista.getSelectedIndex() - 1);
            }
        });
        campo.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "ac-esc");
        campo.getActionMap().put("ac-esc", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) { popup.setVisible(false); }
        });
    }
}
