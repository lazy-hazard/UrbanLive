package condominio;

public class Pago {
    private String codigo;
    private String departamento;
    private String tipoOcupante;
    private String concepto;
    private double monto;
    private String estado;

    public Pago(String codigo, String departamento, String tipoOcupante, String concepto, double monto, String estado) {
        this.codigo = codigo;
        this.departamento = departamento;
        this.tipoOcupante = tipoOcupante;
        this.concepto = concepto;
        this.monto = monto;
        this.estado = estado;
    }

    public String getCodigo() { return codigo; }
    public String getDepartamento() { return departamento; }
    public String getTipoOcupante() { return tipoOcupante; }
    public String getConcepto() { return concepto; }
    public double getMonto() { return monto; }
    public String getEstado() { return estado; }

    public void setEstado(String estado) { this.estado = estado; }
}
