package condominio;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UrbanLiveTest {
    private DatosCondominio datos;

    @BeforeEach
    void preparar() {
        datos = DatosCondominio.getInstancia();
        datos.getDepartamentos().clear();
        datos.getPagos().clear();
        datos.getAreas().clear();
        datos.getReservas().clear();
        datos.getMantenimientos().clear();
    }

    @Test
    void registraYBuscaDepartamento() {
        Departamento d = FabricaEntidades.crearDepartamento("D001", 101, 1, "Inquilino", 300.0);
        datos.getDepartamentos().add(d);

        assertNotNull(datos.buscarDepartamento("D001"));
        assertEquals(101, datos.buscarDepartamento("D001").getNumero());
    }

    @Test
    void calculaTotalDeDeudasPendientes() {
        Departamento d = FabricaEntidades.crearDepartamento("D001", 101, 1, "Inquilino", 300.0);
        datos.getDepartamentos().add(d);
        datos.getPagos().add(FabricaEntidades.crearDeuda("P001", d, "Cuota mensual", 300.0));
        datos.getPagos().add(FabricaEntidades.crearDeuda("P002", d, "Agua", 80.0));
        datos.buscarPago("P002").setEstado("Pagado");

        assertEquals(300.0, datos.totalPendiente("D001"), 0.001);
        assertEquals(1, datos.pagosPendientesPorDepartamento("D001").size());
    }

    @Test
    void conservaReglasDelAreaComun() {
        AreaComun piscina = FabricaEntidades.crearArea(
                "A001", "Piscina", 3, 1, "No ingresar alimentos");
        datos.getAreas().add(piscina);

        AreaComun resultado = datos.buscarArea("A001");
        assertEquals(3, resultado.getMaxHorasReserva());
        assertEquals(1, resultado.getHorasEntreReservas());
        assertEquals("No ingresar alimentos", resultado.getReglas());
    }
}
